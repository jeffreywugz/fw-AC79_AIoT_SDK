﻿namespace IPCTool
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtURL1 = new System.Windows.Forms.TextBox();
            this.btnSSDP = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbbClientIP = new System.Windows.Forms.ComboBox();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupName1 = new System.Windows.Forms.GroupBox();
            this.video1 = new System.Windows.Forms.PictureBox();
            this.lblStatus1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtCmd1 = new System.Windows.Forms.TextBox();
            this.btnSend1 = new System.Windows.Forms.Button();
            this.btnReg1 = new System.Windows.Forms.Button();
            this.groupName2 = new System.Windows.Forms.GroupBox();
            this.video2 = new System.Windows.Forms.PictureBox();
            this.lblStatus2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtCmd2 = new System.Windows.Forms.TextBox();
            this.btnSend2 = new System.Windows.Forms.Button();
            this.btnReg2 = new System.Windows.Forms.Button();
            this.txtURL2 = new System.Windows.Forms.TextBox();
            this.groupName3 = new System.Windows.Forms.GroupBox();
            this.video3 = new System.Windows.Forms.PictureBox();
            this.lblStatus3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtCmd3 = new System.Windows.Forms.TextBox();
            this.btnSend3 = new System.Windows.Forms.Button();
            this.btnReg3 = new System.Windows.Forms.Button();
            this.txtURL3 = new System.Windows.Forms.TextBox();
            this.groupName6 = new System.Windows.Forms.GroupBox();
            this.video6 = new System.Windows.Forms.PictureBox();
            this.lblStatus6 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtCmd6 = new System.Windows.Forms.TextBox();
            this.btnSend6 = new System.Windows.Forms.Button();
            this.btnReg6 = new System.Windows.Forms.Button();
            this.txtURL6 = new System.Windows.Forms.TextBox();
            this.groupName5 = new System.Windows.Forms.GroupBox();
            this.video5 = new System.Windows.Forms.PictureBox();
            this.lblStatus5 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtCmd5 = new System.Windows.Forms.TextBox();
            this.btnSend5 = new System.Windows.Forms.Button();
            this.btnReg5 = new System.Windows.Forms.Button();
            this.txtURL5 = new System.Windows.Forms.TextBox();
            this.groupName4 = new System.Windows.Forms.GroupBox();
            this.video4 = new System.Windows.Forms.PictureBox();
            this.lblStatus4 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtCmd4 = new System.Windows.Forms.TextBox();
            this.btnSend4 = new System.Windows.Forms.Button();
            this.btnReg4 = new System.Windows.Forms.Button();
            this.txtURL4 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLogClear = new System.Windows.Forms.Button();
            this.timerKeepalive = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.groupName1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video1)).BeginInit();
            this.panel3.SuspendLayout();
            this.groupName2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video2)).BeginInit();
            this.panel4.SuspendLayout();
            this.groupName3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video3)).BeginInit();
            this.panel5.SuspendLayout();
            this.groupName6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video6)).BeginInit();
            this.panel8.SuspendLayout();
            this.groupName5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video5)).BeginInit();
            this.panel7.SuspendLayout();
            this.groupName4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video4)).BeginInit();
            this.panel6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtURL1
            // 
            this.txtURL1.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtURL1.Location = new System.Drawing.Point(3, 17);
            this.txtURL1.Name = "txtURL1";
            this.txtURL1.Size = new System.Drawing.Size(262, 21);
            this.txtURL1.TabIndex = 2;
            this.toolTip.SetToolTip(this.txtURL1, "RTSP播放地址");
            // 
            // btnSSDP
            // 
            this.btnSSDP.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSSDP.Location = new System.Drawing.Point(246, 4);
            this.btnSSDP.Name = "btnSSDP";
            this.btnSSDP.Size = new System.Drawing.Size(83, 25);
            this.btnSSDP.TabIndex = 3;
            this.btnSSDP.Text = "启动监听";
            this.btnSSDP.UseVisualStyleBackColor = true;
            this.btnSSDP.Click += new System.EventHandler(this.btnSSDP_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(30, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 14);
            this.label1.TabIndex = 4;
            this.label1.Text = "监听IP";
            // 
            // cbbClientIP
            // 
            this.cbbClientIP.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbbClientIP.FormattingEnabled = true;
            this.cbbClientIP.Location = new System.Drawing.Point(97, 7);
            this.cbbClientIP.Name = "cbbClientIP";
            this.cbbClientIP.Size = new System.Drawing.Size(143, 22);
            this.cbbClientIP.TabIndex = 5;
            // 
            // txtLog
            // 
            this.txtLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLog.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtLog.Location = new System.Drawing.Point(3, 19);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Size = new System.Drawing.Size(375, 589);
            this.txtLog.TabIndex = 6;
            this.txtLog.WordWrap = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupName1
            // 
            this.groupName1.Controls.Add(this.video1);
            this.groupName1.Controls.Add(this.lblStatus1);
            this.groupName1.Controls.Add(this.panel3);
            this.groupName1.Controls.Add(this.txtURL1);
            this.groupName1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupName1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupName1.Location = new System.Drawing.Point(3, 3);
            this.groupName1.Name = "groupName1";
            this.groupName1.Size = new System.Drawing.Size(268, 299);
            this.groupName1.TabIndex = 7;
            this.groupName1.TabStop = false;
            this.groupName1.Text = "监控1";
            // 
            // video1
            // 
            this.video1.BackColor = System.Drawing.Color.Black;
            this.video1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.video1.Image = global::cFW.Properties.Resources.loading;
            this.video1.Location = new System.Drawing.Point(3, 38);
            this.video1.Name = "video1";
            this.video1.Size = new System.Drawing.Size(262, 172);
            this.video1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.video1.TabIndex = 0;
            this.video1.TabStop = false;
            this.toolTip.SetToolTip(this.video1, "双击全屏");
            this.video1.DoubleClick += new System.EventHandler(this.video1_DoubleClick);
            // 
            // lblStatus1
            // 
            this.lblStatus1.AutoEllipsis = true;
            this.lblStatus1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStatus1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblStatus1.Location = new System.Drawing.Point(3, 210);
            this.lblStatus1.Name = "lblStatus1";
            this.lblStatus1.Size = new System.Drawing.Size(262, 56);
            this.lblStatus1.TabIndex = 5;
            this.lblStatus1.Text = "状态:";
            this.lblStatus1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txtCmd1);
            this.panel3.Controls.Add(this.btnSend1);
            this.panel3.Controls.Add(this.btnReg1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(3, 266);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(262, 30);
            this.panel3.TabIndex = 6;
            // 
            // txtCmd1
            // 
            this.txtCmd1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCmd1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtCmd1.Location = new System.Drawing.Point(0, 0);
            this.txtCmd1.Multiline = true;
            this.txtCmd1.Name = "txtCmd1";
            this.txtCmd1.Size = new System.Drawing.Size(159, 30);
            this.txtCmd1.TabIndex = 3;
            this.toolTip.SetToolTip(this.txtCmd1, "MSSDP命令");
            // 
            // btnSend1
            // 
            this.btnSend1.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSend1.Location = new System.Drawing.Point(159, 0);
            this.btnSend1.Name = "btnSend1";
            this.btnSend1.Size = new System.Drawing.Size(54, 30);
            this.btnSend1.TabIndex = 4;
            this.btnSend1.Text = "发送";
            this.toolTip.SetToolTip(this.btnSend1, "发送");
            this.btnSend1.UseVisualStyleBackColor = true;
            this.btnSend1.Click += new System.EventHandler(this.btnSend1_Click);
            // 
            // btnReg1
            // 
            this.btnReg1.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnReg1.Location = new System.Drawing.Point(213, 0);
            this.btnReg1.Name = "btnReg1";
            this.btnReg1.Size = new System.Drawing.Size(49, 30);
            this.btnReg1.TabIndex = 5;
            this.btnReg1.Text = "调试";
            this.toolTip.SetToolTip(this.btnReg1, "寄存器调试模式");
            this.btnReg1.UseVisualStyleBackColor = true;
            this.btnReg1.Click += new System.EventHandler(this.btnReg1_Click);
            // 
            // groupName2
            // 
            this.groupName2.Controls.Add(this.video2);
            this.groupName2.Controls.Add(this.lblStatus2);
            this.groupName2.Controls.Add(this.panel4);
            this.groupName2.Controls.Add(this.txtURL2);
            this.groupName2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupName2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupName2.Location = new System.Drawing.Point(277, 3);
            this.groupName2.Name = "groupName2";
            this.groupName2.Size = new System.Drawing.Size(268, 299);
            this.groupName2.TabIndex = 8;
            this.groupName2.TabStop = false;
            this.groupName2.Text = "监控2";
            // 
            // video2
            // 
            this.video2.BackColor = System.Drawing.Color.Black;
            this.video2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.video2.Image = global::cFW.Properties.Resources.loading;
            this.video2.Location = new System.Drawing.Point(3, 38);
            this.video2.Name = "video2";
            this.video2.Size = new System.Drawing.Size(262, 172);
            this.video2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.video2.TabIndex = 0;
            this.video2.TabStop = false;
            this.video2.DoubleClick += new System.EventHandler(this.video2_DoubleClick);
            // 
            // lblStatus2
            // 
            this.lblStatus2.AutoEllipsis = true;
            this.lblStatus2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStatus2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblStatus2.Location = new System.Drawing.Point(3, 210);
            this.lblStatus2.Name = "lblStatus2";
            this.lblStatus2.Size = new System.Drawing.Size(262, 56);
            this.lblStatus2.TabIndex = 5;
            this.lblStatus2.Text = "状态:";
            this.lblStatus2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtCmd2);
            this.panel4.Controls.Add(this.btnSend2);
            this.panel4.Controls.Add(this.btnReg2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(3, 266);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(262, 30);
            this.panel4.TabIndex = 6;
            // 
            // txtCmd2
            // 
            this.txtCmd2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCmd2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtCmd2.Location = new System.Drawing.Point(0, 0);
            this.txtCmd2.Multiline = true;
            this.txtCmd2.Name = "txtCmd2";
            this.txtCmd2.Size = new System.Drawing.Size(159, 30);
            this.txtCmd2.TabIndex = 3;
            // 
            // btnSend2
            // 
            this.btnSend2.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSend2.Location = new System.Drawing.Point(159, 0);
            this.btnSend2.Name = "btnSend2";
            this.btnSend2.Size = new System.Drawing.Size(54, 30);
            this.btnSend2.TabIndex = 4;
            this.btnSend2.Text = "发送";
            this.btnSend2.UseVisualStyleBackColor = true;
            this.btnSend2.Click += new System.EventHandler(this.btnSend2_Click);
            // 
            // btnReg2
            // 
            this.btnReg2.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnReg2.Location = new System.Drawing.Point(213, 0);
            this.btnReg2.Name = "btnReg2";
            this.btnReg2.Size = new System.Drawing.Size(49, 30);
            this.btnReg2.TabIndex = 6;
            this.btnReg2.Text = "调试";
            this.btnReg2.UseVisualStyleBackColor = true;
            this.btnReg2.Click += new System.EventHandler(this.btnReg2_Click);
            // 
            // txtURL2
            // 
            this.txtURL2.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtURL2.Location = new System.Drawing.Point(3, 17);
            this.txtURL2.Name = "txtURL2";
            this.txtURL2.Size = new System.Drawing.Size(262, 21);
            this.txtURL2.TabIndex = 2;
            // 
            // groupName3
            // 
            this.groupName3.Controls.Add(this.video3);
            this.groupName3.Controls.Add(this.lblStatus3);
            this.groupName3.Controls.Add(this.panel5);
            this.groupName3.Controls.Add(this.txtURL3);
            this.groupName3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupName3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupName3.Location = new System.Drawing.Point(551, 3);
            this.groupName3.Name = "groupName3";
            this.groupName3.Size = new System.Drawing.Size(270, 299);
            this.groupName3.TabIndex = 9;
            this.groupName3.TabStop = false;
            this.groupName3.Text = "监控3";
            // 
            // video3
            // 
            this.video3.BackColor = System.Drawing.Color.Black;
            this.video3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.video3.Image = global::cFW.Properties.Resources.loading;
            this.video3.Location = new System.Drawing.Point(3, 38);
            this.video3.Name = "video3";
            this.video3.Size = new System.Drawing.Size(264, 172);
            this.video3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.video3.TabIndex = 0;
            this.video3.TabStop = false;
            this.video3.DoubleClick += new System.EventHandler(this.video3_DoubleClick);
            // 
            // lblStatus3
            // 
            this.lblStatus3.AutoEllipsis = true;
            this.lblStatus3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStatus3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblStatus3.Location = new System.Drawing.Point(3, 210);
            this.lblStatus3.Name = "lblStatus3";
            this.lblStatus3.Size = new System.Drawing.Size(264, 56);
            this.lblStatus3.TabIndex = 5;
            this.lblStatus3.Text = "状态:";
            this.lblStatus3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txtCmd3);
            this.panel5.Controls.Add(this.btnSend3);
            this.panel5.Controls.Add(this.btnReg3);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(3, 266);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(264, 30);
            this.panel5.TabIndex = 6;
            // 
            // txtCmd3
            // 
            this.txtCmd3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCmd3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtCmd3.Location = new System.Drawing.Point(0, 0);
            this.txtCmd3.Multiline = true;
            this.txtCmd3.Name = "txtCmd3";
            this.txtCmd3.Size = new System.Drawing.Size(160, 30);
            this.txtCmd3.TabIndex = 3;
            // 
            // btnSend3
            // 
            this.btnSend3.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSend3.Location = new System.Drawing.Point(160, 0);
            this.btnSend3.Name = "btnSend3";
            this.btnSend3.Size = new System.Drawing.Size(55, 30);
            this.btnSend3.TabIndex = 4;
            this.btnSend3.Text = "发送";
            this.btnSend3.UseVisualStyleBackColor = true;
            this.btnSend3.Click += new System.EventHandler(this.btnSend3_Click);
            // 
            // btnReg3
            // 
            this.btnReg3.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnReg3.Location = new System.Drawing.Point(215, 0);
            this.btnReg3.Name = "btnReg3";
            this.btnReg3.Size = new System.Drawing.Size(49, 30);
            this.btnReg3.TabIndex = 6;
            this.btnReg3.Text = "调试";
            this.btnReg3.UseVisualStyleBackColor = true;
            this.btnReg3.Click += new System.EventHandler(this.btnReg3_Click);
            // 
            // txtURL3
            // 
            this.txtURL3.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtURL3.Location = new System.Drawing.Point(3, 17);
            this.txtURL3.Name = "txtURL3";
            this.txtURL3.Size = new System.Drawing.Size(264, 21);
            this.txtURL3.TabIndex = 2;
            // 
            // groupName6
            // 
            this.groupName6.Controls.Add(this.video6);
            this.groupName6.Controls.Add(this.lblStatus6);
            this.groupName6.Controls.Add(this.panel8);
            this.groupName6.Controls.Add(this.txtURL6);
            this.groupName6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupName6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupName6.Location = new System.Drawing.Point(551, 308);
            this.groupName6.Name = "groupName6";
            this.groupName6.Size = new System.Drawing.Size(270, 300);
            this.groupName6.TabIndex = 12;
            this.groupName6.TabStop = false;
            this.groupName6.Text = "监控6";
            // 
            // video6
            // 
            this.video6.BackColor = System.Drawing.Color.Black;
            this.video6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.video6.Image = global::cFW.Properties.Resources.loading;
            this.video6.Location = new System.Drawing.Point(3, 38);
            this.video6.Name = "video6";
            this.video6.Size = new System.Drawing.Size(264, 173);
            this.video6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.video6.TabIndex = 0;
            this.video6.TabStop = false;
            this.video6.DoubleClick += new System.EventHandler(this.video6_DoubleClick);
            // 
            // lblStatus6
            // 
            this.lblStatus6.AutoEllipsis = true;
            this.lblStatus6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStatus6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus6.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblStatus6.Location = new System.Drawing.Point(3, 211);
            this.lblStatus6.Name = "lblStatus6";
            this.lblStatus6.Size = new System.Drawing.Size(264, 56);
            this.lblStatus6.TabIndex = 5;
            this.lblStatus6.Text = "状态:";
            this.lblStatus6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txtCmd6);
            this.panel8.Controls.Add(this.btnSend6);
            this.panel8.Controls.Add(this.btnReg6);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(3, 267);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(264, 30);
            this.panel8.TabIndex = 6;
            // 
            // txtCmd6
            // 
            this.txtCmd6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCmd6.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtCmd6.Location = new System.Drawing.Point(0, 0);
            this.txtCmd6.Multiline = true;
            this.txtCmd6.Name = "txtCmd6";
            this.txtCmd6.Size = new System.Drawing.Size(160, 30);
            this.txtCmd6.TabIndex = 3;
            // 
            // btnSend6
            // 
            this.btnSend6.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSend6.Location = new System.Drawing.Point(160, 0);
            this.btnSend6.Name = "btnSend6";
            this.btnSend6.Size = new System.Drawing.Size(55, 30);
            this.btnSend6.TabIndex = 4;
            this.btnSend6.Text = "发送";
            this.btnSend6.UseVisualStyleBackColor = true;
            this.btnSend6.Click += new System.EventHandler(this.btnSend6_Click);
            // 
            // btnReg6
            // 
            this.btnReg6.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnReg6.Location = new System.Drawing.Point(215, 0);
            this.btnReg6.Name = "btnReg6";
            this.btnReg6.Size = new System.Drawing.Size(49, 30);
            this.btnReg6.TabIndex = 6;
            this.btnReg6.Text = "调试";
            this.btnReg6.UseVisualStyleBackColor = true;
            this.btnReg6.Click += new System.EventHandler(this.btnReg6_Click);
            // 
            // txtURL6
            // 
            this.txtURL6.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtURL6.Location = new System.Drawing.Point(3, 17);
            this.txtURL6.Name = "txtURL6";
            this.txtURL6.Size = new System.Drawing.Size(264, 21);
            this.txtURL6.TabIndex = 2;
            // 
            // groupName5
            // 
            this.groupName5.Controls.Add(this.video5);
            this.groupName5.Controls.Add(this.lblStatus5);
            this.groupName5.Controls.Add(this.panel7);
            this.groupName5.Controls.Add(this.txtURL5);
            this.groupName5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupName5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupName5.Location = new System.Drawing.Point(277, 308);
            this.groupName5.Name = "groupName5";
            this.groupName5.Size = new System.Drawing.Size(268, 300);
            this.groupName5.TabIndex = 11;
            this.groupName5.TabStop = false;
            this.groupName5.Text = "监控5";
            // 
            // video5
            // 
            this.video5.BackColor = System.Drawing.Color.Black;
            this.video5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.video5.Image = global::cFW.Properties.Resources.loading;
            this.video5.Location = new System.Drawing.Point(3, 38);
            this.video5.Name = "video5";
            this.video5.Size = new System.Drawing.Size(262, 173);
            this.video5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.video5.TabIndex = 0;
            this.video5.TabStop = false;
            this.video5.DoubleClick += new System.EventHandler(this.video5_DoubleClick);
            // 
            // lblStatus5
            // 
            this.lblStatus5.AutoEllipsis = true;
            this.lblStatus5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStatus5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus5.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblStatus5.Location = new System.Drawing.Point(3, 211);
            this.lblStatus5.Name = "lblStatus5";
            this.lblStatus5.Size = new System.Drawing.Size(262, 56);
            this.lblStatus5.TabIndex = 5;
            this.lblStatus5.Text = "状态:";
            this.lblStatus5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txtCmd5);
            this.panel7.Controls.Add(this.btnSend5);
            this.panel7.Controls.Add(this.btnReg5);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(3, 267);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(262, 30);
            this.panel7.TabIndex = 6;
            // 
            // txtCmd5
            // 
            this.txtCmd5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCmd5.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtCmd5.Location = new System.Drawing.Point(0, 0);
            this.txtCmd5.Multiline = true;
            this.txtCmd5.Name = "txtCmd5";
            this.txtCmd5.Size = new System.Drawing.Size(158, 30);
            this.txtCmd5.TabIndex = 3;
            // 
            // btnSend5
            // 
            this.btnSend5.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSend5.Location = new System.Drawing.Point(158, 0);
            this.btnSend5.Name = "btnSend5";
            this.btnSend5.Size = new System.Drawing.Size(55, 30);
            this.btnSend5.TabIndex = 4;
            this.btnSend5.Text = "发送";
            this.btnSend5.UseVisualStyleBackColor = true;
            this.btnSend5.Click += new System.EventHandler(this.btnSend5_Click);
            // 
            // btnReg5
            // 
            this.btnReg5.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnReg5.Location = new System.Drawing.Point(213, 0);
            this.btnReg5.Name = "btnReg5";
            this.btnReg5.Size = new System.Drawing.Size(49, 30);
            this.btnReg5.TabIndex = 6;
            this.btnReg5.Text = "调试";
            this.btnReg5.UseVisualStyleBackColor = true;
            this.btnReg5.Click += new System.EventHandler(this.btnReg5_Click);
            // 
            // txtURL5
            // 
            this.txtURL5.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtURL5.Location = new System.Drawing.Point(3, 17);
            this.txtURL5.Name = "txtURL5";
            this.txtURL5.Size = new System.Drawing.Size(262, 21);
            this.txtURL5.TabIndex = 2;
            // 
            // groupName4
            // 
            this.groupName4.Controls.Add(this.video4);
            this.groupName4.Controls.Add(this.lblStatus4);
            this.groupName4.Controls.Add(this.panel6);
            this.groupName4.Controls.Add(this.txtURL4);
            this.groupName4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupName4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupName4.Location = new System.Drawing.Point(3, 308);
            this.groupName4.Name = "groupName4";
            this.groupName4.Size = new System.Drawing.Size(268, 300);
            this.groupName4.TabIndex = 10;
            this.groupName4.TabStop = false;
            this.groupName4.Text = "监控4";
            // 
            // video4
            // 
            this.video4.BackColor = System.Drawing.Color.Black;
            this.video4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.video4.Image = global::cFW.Properties.Resources.loading;
            this.video4.Location = new System.Drawing.Point(3, 38);
            this.video4.Name = "video4";
            this.video4.Size = new System.Drawing.Size(262, 173);
            this.video4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.video4.TabIndex = 0;
            this.video4.TabStop = false;
            this.video4.DoubleClick += new System.EventHandler(this.video4_DoubleClick);
            // 
            // lblStatus4
            // 
            this.lblStatus4.AutoEllipsis = true;
            this.lblStatus4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStatus4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblStatus4.Location = new System.Drawing.Point(3, 211);
            this.lblStatus4.Name = "lblStatus4";
            this.lblStatus4.Size = new System.Drawing.Size(262, 56);
            this.lblStatus4.TabIndex = 5;
            this.lblStatus4.Text = "状态:";
            this.lblStatus4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txtCmd4);
            this.panel6.Controls.Add(this.btnSend4);
            this.panel6.Controls.Add(this.btnReg4);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(3, 267);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(262, 30);
            this.panel6.TabIndex = 6;
            // 
            // txtCmd4
            // 
            this.txtCmd4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCmd4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtCmd4.Location = new System.Drawing.Point(0, 0);
            this.txtCmd4.Multiline = true;
            this.txtCmd4.Name = "txtCmd4";
            this.txtCmd4.Size = new System.Drawing.Size(159, 30);
            this.txtCmd4.TabIndex = 3;
            // 
            // btnSend4
            // 
            this.btnSend4.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSend4.Location = new System.Drawing.Point(159, 0);
            this.btnSend4.Name = "btnSend4";
            this.btnSend4.Size = new System.Drawing.Size(54, 30);
            this.btnSend4.TabIndex = 4;
            this.btnSend4.Text = "发送";
            this.btnSend4.UseVisualStyleBackColor = true;
            this.btnSend4.Click += new System.EventHandler(this.btnSend4_Click);
            // 
            // btnReg4
            // 
            this.btnReg4.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnReg4.Location = new System.Drawing.Point(213, 0);
            this.btnReg4.Name = "btnReg4";
            this.btnReg4.Size = new System.Drawing.Size(49, 30);
            this.btnReg4.TabIndex = 6;
            this.btnReg4.Text = "调试";
            this.btnReg4.UseVisualStyleBackColor = true;
            this.btnReg4.Click += new System.EventHandler(this.btnReg4_Click);
            // 
            // txtURL4
            // 
            this.txtURL4.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtURL4.Location = new System.Drawing.Point(3, 17);
            this.txtURL4.Name = "txtURL4";
            this.txtURL4.Size = new System.Drawing.Size(262, 21);
            this.txtURL4.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtLog);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(832, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(381, 611);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "日志区:";
            // 
            // btnLogClear
            // 
            this.btnLogClear.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnLogClear.Location = new System.Drawing.Point(5, 5);
            this.btnLogClear.Name = "btnLogClear";
            this.btnLogClear.Size = new System.Drawing.Size(83, 25);
            this.btnLogClear.TabIndex = 14;
            this.btnLogClear.Text = "清空日志";
            this.btnLogClear.UseVisualStyleBackColor = true;
            this.btnLogClear.Click += new System.EventHandler(this.btnLogClear_Click);
            // 
            // timerKeepalive
            // 
            this.timerKeepalive.Interval = 2000;
            this.timerKeepalive.Tick += new System.EventHandler(this.timerKeepalive_Tick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(824, 611);
            this.panel1.TabIndex = 15;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.Controls.Add(this.groupName1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupName2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupName3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupName4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.groupName5, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.groupName6, 2, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(824, 611);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.btnSSDP);
            this.panel2.Controls.Add(this.cbbClientIP);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1213, 35);
            this.panel2.TabIndex = 16;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btnLogClear);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel9.Location = new System.Drawing.Point(830, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(383, 35);
            this.panel9.TabIndex = 15;
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter1.Location = new System.Drawing.Point(824, 35);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(8, 611);
            this.splitter1.TabIndex = 7;
            this.splitter1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 646);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "cWF(Ver: 20201211)";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupName1.ResumeLayout(false);
            this.groupName1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupName2.ResumeLayout(false);
            this.groupName2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupName3.ResumeLayout(false);
            this.groupName3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video3)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.groupName6.ResumeLayout(false);
            this.groupName6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video6)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.groupName5.ResumeLayout(false);
            this.groupName5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video5)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.groupName4.ResumeLayout(false);
            this.groupName4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.video4)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox video1;
        private System.Windows.Forms.TextBox txtURL1;
        private System.Windows.Forms.Button btnSSDP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbbClientIP;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupName1;
        private System.Windows.Forms.Label lblStatus1;
        private System.Windows.Forms.Button btnSend1;
        private System.Windows.Forms.TextBox txtCmd1;
        private System.Windows.Forms.GroupBox groupName2;
        private System.Windows.Forms.Label lblStatus2;
        private System.Windows.Forms.Button btnSend2;
        private System.Windows.Forms.TextBox txtCmd2;
        private System.Windows.Forms.TextBox txtURL2;
        private System.Windows.Forms.PictureBox video2;
        private System.Windows.Forms.GroupBox groupName3;
        private System.Windows.Forms.Label lblStatus3;
        private System.Windows.Forms.Button btnSend3;
        private System.Windows.Forms.TextBox txtCmd3;
        private System.Windows.Forms.TextBox txtURL3;
        private System.Windows.Forms.PictureBox video3;
        private System.Windows.Forms.GroupBox groupName6;
        private System.Windows.Forms.Label lblStatus6;
        private System.Windows.Forms.Button btnSend6;
        private System.Windows.Forms.TextBox txtCmd6;
        private System.Windows.Forms.TextBox txtURL6;
        private System.Windows.Forms.PictureBox video6;
        private System.Windows.Forms.GroupBox groupName5;
        private System.Windows.Forms.Label lblStatus5;
        private System.Windows.Forms.Button btnSend5;
        private System.Windows.Forms.TextBox txtCmd5;
        private System.Windows.Forms.TextBox txtURL5;
        private System.Windows.Forms.PictureBox video5;
        private System.Windows.Forms.GroupBox groupName4;
        private System.Windows.Forms.Label lblStatus4;
        private System.Windows.Forms.Button btnSend4;
        private System.Windows.Forms.TextBox txtCmd4;
        private System.Windows.Forms.TextBox txtURL4;
        private System.Windows.Forms.PictureBox video4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnLogClear;
        private System.Windows.Forms.Timer timerKeepalive;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btnReg1;
        private System.Windows.Forms.Button btnReg2;
        private System.Windows.Forms.Button btnReg3;
        private System.Windows.Forms.Button btnReg6;
        private System.Windows.Forms.Button btnReg5;
        private System.Windows.Forms.Button btnReg4;
        private System.Windows.Forms.ToolTip toolTip;
    }
}

