﻿using cFW;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPCTool
{
    public partial class Form1 : Form
    {
        private UdpClient udpClient;
        public Form1()
        {
            InitializeComponent();
            //this.txtURL1.Text = "rtsp://192.168.95.2/avi_pcm_rt/front.sd";
            //this.txtCmd1.Text = "{\"UID\":\"A1\"}":
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            initComponet(); //初始化控件
            List<string> ips = SocketUtils.GetLocalIP();
            for(int i=0; i<ips.Count; i++)
            {
                cbbClientIP.Items.Add(ips[i]);
            }
            //cbbClientIP.SelectedItem = "192.168.95.1";
            cbbClientIP.SelectedIndex = 0;
            
        }
        #region SSDP Socket 功能
        private void btnSSDP_Click(object sender, EventArgs e)
        {
            if(btnSSDP.Text == "启动监听")
            {
                btnSSDP.Text = "运行中";
                cbbClientIP.Enabled = false;
                listenSSDP();
                timer1.Start();
                timerKeepalive.Start();//保持广播包心跳
            }
            else
            {
                btnSSDP.Text = "启动监听";
                cbbClientIP.Enabled = true;
                unListenSSDP();
                timer1.Stop();
                timerKeepalive.Stop();
                //全部资源回收
                for (int i=0; i<notifys.Length; i++)
                {
                    if(notifys[i] != null)
                    {
                        clearGroup(i);
                    }
                }
                LOG("监听已停止。所有资源已回收.");
            }
        }

        private void listenSSDP()
        {
            udpClient = new UdpClient();
            int PORT = 3333;
            string ip = cbbClientIP.SelectedItem.ToString();
            LOG("监听IP " + ip + ":" + PORT);
            udpClient.Client.Bind(new IPEndPoint(IPAddress.Parse(ip), PORT));//

            var from = new IPEndPoint(0, 0);
            Task.Run(() =>
            {
               try
                {
                    while (true)
                    {
                        try
                        {
                            var recvBuffer = udpClient.Receive(ref from);
                            string str = Encoding.UTF8.GetString(recvBuffer);
                            string[] vals = str.Split(' ');
                            if (vals.Length < 2)
                            {
                                continue;
                            }
                            string type = str.Split(' ')[0];
                            //string json = str.Split(' ')[1];
                            string json = str.Replace(type, "");
                            string hostname = from.Address + ":" + from.Port;
                            if (type == "MSSDP_NOTIFY")
                            {
                                MSSDPNotifyModel notify = JsonConvert.DeserializeObject<MSSDPNotifyModel>(json);
                                string UID = notify.UID;
                                LOG("收到广播: " + hostname + "[" + UID + "]=> " + type);
                                notify.hostname = from.Address.ToString();
                                notify.port = from.Port;
                                notify.tick = time();
                                updateVideo(notify);
                            }else if(type == "MSSDP_REGISTER")
                            {
                                Dictionary<string, object> register = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                                LOG("收到广播: " + hostname + "[" + "]=> ");
                            }else if(type == "MSSDP_SEARCH")
                            {
                                //广播包过滤
                            }
                            else
                            {
                                LOG("收到广播: " + hostname + "[.]=> " + type);
                            }
                        }
                        catch (ObjectDisposedException ex)
                        {
                            LOG("异常ObjectDisposedException:" + ex.Message);
                            break;
                        }
                        catch (SocketException ex)
                        {
                            LOG("异常SocketException:" + ex.Message);
                            break;
                        }
                        catch(Exception ex)
                        {
                            LOG("异常:" + ex.Message);
                            //break;
                        }
                    }
                }
                catch(Exception ex)
                {
                   LOG("关闭:" + ex.Message);
                }
            });
        }
        private void unListenSSDP()
        {
            udpClient.Close();
        }
        #endregion

        private void timer1_Tick(object sender, EventArgs e)
        {
            //对notifys没有更新时间戳的设备进行删除
            for(int i=0; i<notifys.Length; i++)
            {
                if(notifys[i] == null)
                {
                    continue;
                }
                long t = time() - notifys[i].tick;
                if (t > 15) //15秒
                {
                    //资源回收
                    LOG(notifys[i].UID + "资源回收" + t + "秒.");
                    clearGroup(i);
                }
            }
            showVideo();
        }
        private void timerKeepalive_Tick(object sender, EventArgs e)
        {
            //var d = Encoding.UTF8.GetBytes("MSSDP_SEARCH {\"UID\":\"xxxx\"}");
            var d = Encoding.UTF8.GetBytes("MSSDP_SEARCH ");
            udpClient.Send(d, d.Length, "255.255.255.255", 3333);
        }

        private void updateVideo(MSSDPNotifyModel notify)
        {
            Console.WriteLine("updateVideo: " + notify.UID);
            bool flag = false;
            for(int i=0; i<notifys.Length; i++)
            {
                if(notifys[i] == null)
                {
                    continue;
                }
                if(notifys[i].RTSP == notify.RTSP)
                {
                    //LOG(notifys[i].UID + "更新TS: " + notify.tick);
                    notifys[i] = notify; //更新时间戳
                    flag = true;
                    break;
                }
            }
            //表示新增加的
            if(flag == false)
            {
                for(int i=0; i<notifys.Length; i++)
                {
                    if(notifys[i] == null)
                    {
                        notifys[i] = notify; //设置
                        LOG(notifys[i].UID + "新设置TS: " + notify.tick);
                        break;
                    }
                }
            }
        }
        
        private void showVideo()
        {
            Console.WriteLine("showVideo");
            for(int i=0; i<notifys.Length; i++)
            {
                if(notifys[i] == null)
                {
                    //清空
                    clearGroup(i);
                }
                else
                {
                    //显示
                    listUrl[i].Text = notifys[i].RTSP;
                    /*
                    string label = string.Format("({0}) RSSI[{1}] TF[{2}] \r\nKEY0[{3}] KEY2[{4}] dB[{5}] VOL[{6}] \r\nUID[{7}]\r\nRX_DATA[{8}]",
                        notifys[i].hostname, notifys[i].SIGNAL, notifys[i].SD_STATUS,
                        notifys[i].KEY0, notifys[i].KEY1, notifys[i].dB, notifys[i].BAT_VOL,
                        notifys[i].UID,
                        notifys[i].RX_DATA);
                    */
                    string label = string.Format("({0}) RSSI[{1}] TF[{2}] KEY0[{3}] KEY2[{4}] dB[{5}] VOL[{6}] UID[{7}]",
                        notifys[i].hostname, notifys[i].SIGNAL, notifys[i].SD_STATUS,
                        notifys[i].KEY0, notifys[i].KEY1, notifys[i].dB, notifys[i].BAT_VOL,
                        notifys[i].UID);

                    listStatus[i].Text = label;
                    LOG("视频播放中?: " + player[i].isRunning());
                    if (player[i].isRunning() == false)
                    {
                        Console.WriteLine("播放视频." + player[i].isRunning());
                        LOG("播放视频: " + notifys[i].RTSP);
                        player[i].play(notifys[i].RTSP);
                    }
                    
                }
            }
        }
        private void clearGroup(int index)
        {
            player[index].stop();
            listUrl[index].Text = "";
            listStatus[index].Text = "状态";
            notifys[index] = null;
            
        }


        #region 抽象功能
        /// <summary>
        /// 当前时间戳，秒
        /// </summary>
        /// <returns></returns>
        public long time()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds);
        }
        /// <summary>
        /// 日志
        /// </summary>
        /// <param name="msg"></param>
        public void LOG(string msg)
        {
            Invoke(new MethodInvoker(delegate ()
            {
                var str = txtLog.Text;
                if (str.Length > 128 * 1024)
                {
                    str = str.Substring(0, 32 * 1024);
                    Console.WriteLine("substring..");
                }
                DateTime dt = DateTime.Now;
                var ss = "[" + string.Format("{0:HH:mm:ss.fff}", dt) + "] " + msg + "\r\n" + str;
                txtLog.Text = ss;
            }));
        }
        private void btnLogClear_Click(object sender, EventArgs e)
        {
            txtLog.Text = "";
        }

        private static int MAX_VIDEO = 6;
        MSSDPNotifyModel[] notifys = new MSSDPNotifyModel[MAX_VIDEO];
        TextBox[] listUrl = new TextBox[MAX_VIDEO];
        Label[] listStatus = new Label[MAX_VIDEO];
        TextBox[] listCmd = new TextBox[MAX_VIDEO];
        GroupBox[] listGroup = new GroupBox[MAX_VIDEO];
        RTSPPlayer[] player = new RTSPPlayer[MAX_VIDEO];
        public void initComponet()
        {
            for (int i = 0; i < notifys.Length; i++)
            {
                notifys[i] = null;
            }

            //设置控件
            listGroup[0] = groupName1;
            listUrl[0] = txtURL1;
            player[0] = new RTSPPlayer(this, video1);
            listStatus[0] = lblStatus1;
            listCmd[0] = txtCmd1;

            listGroup[1] = groupName2;
            listUrl[1] = txtURL2;
            player[1] = new RTSPPlayer(this, video2);
            listStatus[1] = lblStatus2;
            listCmd[1] = txtCmd2;

            listGroup[2] = groupName3;
            listUrl[2] = txtURL3;
            player[2] = new RTSPPlayer(this, video3);
            listStatus[2] = lblStatus3;
            listCmd[2] = txtCmd3;

            listGroup[3] = groupName4;
            listUrl[3] = txtURL4;
            player[3] = new RTSPPlayer(this, video4);
            listStatus[3] = lblStatus4;
            listCmd[3] = txtCmd4;

            listGroup[4] = groupName5;
            listUrl[4] = txtURL5;
            player[4] = new RTSPPlayer(this, video5);
            listStatus[4] = lblStatus5;
            listCmd[4] = txtCmd5;

            listGroup[5] = groupName6;
            listUrl[5] = txtURL6;
            player[5] = new RTSPPlayer(this, video6);
            listStatus[5] = lblStatus6;
            listCmd[5] = txtCmd6;

        }

        #endregion

        #region 事件发送功能
        private void btnSend1_Click(object sender, EventArgs e)
        {
            string msg = txtCmd1.Text;
            bool f = sendToDevice(0, msg);
            if(f == true)
            {
                txtCmd1.Text = "";
            }
        }
        private void btnSend2_Click(object sender, EventArgs e)
        {
            string msg = txtCmd2.Text;
            bool f = sendToDevice(1, msg);
            if(f == true)
            {
                txtCmd2.Text = "";
            }
        }
        private void btnSend3_Click(object sender, EventArgs e)
        {
            string msg = txtCmd3.Text;
            bool f = sendToDevice(2, msg);
            if(f == true)
            {
                txtCmd3.Text = "";
            }
        }
        private void btnSend4_Click(object sender, EventArgs e)
        {
            string msg = txtCmd4.Text;
            bool f = sendToDevice(3, msg);
            if(f == true)
            {
                txtCmd4.Text = "";
            }
        }
        private void btnSend5_Click(object sender, EventArgs e)
        {
            string msg = txtCmd5.Text;
            bool f = sendToDevice(4, msg);
            if(f == true)
            {
                txtCmd5.Text = "";
            }
        }
        private void btnSend6_Click(object sender, EventArgs e)
        {
            string msg = txtCmd6.Text;
            bool f = sendToDevice(5, msg);
            if(f == true)
            {
                txtCmd6.Text = "";
            }
        }
        private bool sendToDevice(int index, string msg)
        {
            MSSDPNotifyModel notify = notifys[index];
            if(notify == null)
            {
                LOG("设备不在线.");
                return false;
            }
            var data = Encoding.UTF8.GetBytes("MSSDP_SEARCH " + msg);
            string hostname = notify.hostname;
            //"255.255.255.255"
            udpClient.Send(data, data.Length, hostname, 3333);
            LOG("发送广播:" + hostname);
            return true;
        }

        #endregion

        #region 寄存器发送功能
        private void btnReg1_Click(object sender, EventArgs e)
        {
            showRegConfigWidnow(0);
        }
        private void btnReg2_Click(object sender, EventArgs e)
        {
            showRegConfigWidnow(1);
        }
        private void btnReg3_Click(object sender, EventArgs e)
        {
            showRegConfigWidnow(2);
        }
        private void btnReg4_Click(object sender, EventArgs e)
        {
            showRegConfigWidnow(3);
        }
        private void btnReg5_Click(object sender, EventArgs e)
        {
            showRegConfigWidnow(4);
        }
        private void btnReg6_Click(object sender, EventArgs e)
        {
            showRegConfigWidnow(5);
        }

        RegConfig regConfig = null;
        private bool showRegConfigWidnow(int index)
        {
            MSSDPNotifyModel notify = notifys[index];
            if(notify == null)
            {
                LOG("设备不在线");
                return false;
            }
            regConfig = new RegConfig();
            regConfig.cfgHostname = notify.hostname;
            regConfig.cfgPort = 3333;
            regConfig.serverHostname = cbbClientIP.SelectedItem.ToString();
            regConfig.serverPort = 3334;
            regConfig.screenID = (index + 1);//屏幕监控ID
            regConfig.Show();
            return true;
        }
        #endregion

        #region 是否全屏显示
        bool isFull = false;
        private void video1_DoubleClick(object sender, EventArgs e)
        {
            if(isFull)
            {
                videoShow();
                isFull = false;
            }
            else
            {
                videoHide();
                groupName1.Show();
                isFull = true;
            }
        }
        private void video2_DoubleClick(object sender, EventArgs e)
        {
            if (isFull)
            {
                videoShow();
                isFull = false;
            }
            else
            {
                videoHide();
                groupName2.Show();
                isFull = true;
            }
        }
        private void video3_DoubleClick(object sender, EventArgs e)
        {
            if (isFull)
            {
                videoShow();
                isFull = false;
            }
            else
            {
                videoHide();
                groupName3.Show();
                isFull = true;
            }
        }
        private void video4_DoubleClick(object sender, EventArgs e)
        {
            if (isFull)
            {
                videoShow();
                this.tableLayoutPanel1.SetRow(groupName4, 1);
                isFull = false;
            }
            else
            {
                videoHide();
                groupName4.Show();
                this.tableLayoutPanel1.SetRow(groupName4, 0);
                isFull = true;
            }
        }
        private void video5_DoubleClick(object sender, EventArgs e)
        {
            if (isFull)
            {
                videoShow();
                this.tableLayoutPanel1.SetRow(groupName5, 1);
                isFull = false;
            }
            else
            {
                videoHide();
                groupName5.Show();
                this.tableLayoutPanel1.SetRow(groupName5, 0);
                isFull = true;
            }
        }
        private void video6_DoubleClick(object sender, EventArgs e)
        {
            if (isFull)
            {
                videoShow();
                this.tableLayoutPanel1.SetRow(groupName6, 1);
                isFull = false;
            }
            else
            {
                videoHide();
                groupName6.Show();
                this.tableLayoutPanel1.SetRow(groupName6, 0);
                isFull = true;
            }
        }

        private void videoHide()
        {
            groupName1.Hide();
            groupName2.Hide();
            groupName3.Hide();
            groupName4.Hide();
            groupName5.Hide();
            groupName6.Hide();
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.RowCount = 1;
        }
        private void videoShow()
        {
            groupName1.Show();
            groupName2.Show();
            groupName3.Show();
            groupName4.Show();
            groupName5.Show();
            groupName6.Show();
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.RowCount = 2;
        }
        #endregion

    }
}
