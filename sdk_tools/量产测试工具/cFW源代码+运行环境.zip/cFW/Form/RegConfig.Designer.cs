﻿namespace cFW
{
    partial class RegConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegConfig));
            this.tablePanel = new System.Windows.Forms.TableLayoutPanel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.val11 = new System.Windows.Forms.TextBox();
            this.add11 = new System.Windows.Forms.Button();
            this.sub11 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.val10 = new System.Windows.Forms.TextBox();
            this.add10 = new System.Windows.Forms.Button();
            this.sub10 = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.val9 = new System.Windows.Forms.TextBox();
            this.add9 = new System.Windows.Forms.Button();
            this.sub9 = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.val8 = new System.Windows.Forms.TextBox();
            this.add8 = new System.Windows.Forms.Button();
            this.sub8 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.val7 = new System.Windows.Forms.TextBox();
            this.add7 = new System.Windows.Forms.Button();
            this.sub7 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.val6 = new System.Windows.Forms.TextBox();
            this.add6 = new System.Windows.Forms.Button();
            this.sub6 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.val5 = new System.Windows.Forms.TextBox();
            this.add5 = new System.Windows.Forms.Button();
            this.sub5 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.val4 = new System.Windows.Forms.TextBox();
            this.add4 = new System.Windows.Forms.Button();
            this.sub4 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.val3 = new System.Windows.Forms.TextBox();
            this.add3 = new System.Windows.Forms.Button();
            this.sub3 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.val2 = new System.Windows.Forms.TextBox();
            this.add2 = new System.Windows.Forms.Button();
            this.sub2 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.val1 = new System.Windows.Forms.TextBox();
            this.add1 = new System.Windows.Forms.Button();
            this.sub1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.val0 = new System.Windows.Forms.TextBox();
            this.add0 = new System.Windows.Forms.Button();
            this.sub0 = new System.Windows.Forms.Button();
            this.reg11 = new System.Windows.Forms.NumericUpDown();
            this.reg10 = new System.Windows.Forms.NumericUpDown();
            this.reg9 = new System.Windows.Forms.NumericUpDown();
            this.reg8 = new System.Windows.Forms.NumericUpDown();
            this.reg7 = new System.Windows.Forms.NumericUpDown();
            this.reg6 = new System.Windows.Forms.NumericUpDown();
            this.reg5 = new System.Windows.Forms.NumericUpDown();
            this.reg4 = new System.Windows.Forms.NumericUpDown();
            this.reg3 = new System.Windows.Forms.NumericUpDown();
            this.reg2 = new System.Windows.Forms.NumericUpDown();
            this.reg1 = new System.Windows.Forms.NumericUpDown();
            this.addr11 = new System.Windows.Forms.TextBox();
            this.addr10 = new System.Windows.Forms.TextBox();
            this.addr9 = new System.Windows.Forms.TextBox();
            this.addr8 = new System.Windows.Forms.TextBox();
            this.addr7 = new System.Windows.Forms.TextBox();
            this.addr6 = new System.Windows.Forms.TextBox();
            this.addr5 = new System.Windows.Forms.TextBox();
            this.addr4 = new System.Windows.Forms.TextBox();
            this.addr3 = new System.Windows.Forms.TextBox();
            this.btnRead2 = new System.Windows.Forms.Button();
            this.addr2 = new System.Windows.Forms.TextBox();
            this.addr1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnRead0 = new System.Windows.Forms.Button();
            this.btnWrite0 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnWrite1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.btnWrite2 = new System.Windows.Forms.Button();
            this.btnWrite3 = new System.Windows.Forms.Button();
            this.btnWrite4 = new System.Windows.Forms.Button();
            this.btnWrite5 = new System.Windows.Forms.Button();
            this.btnWrite6 = new System.Windows.Forms.Button();
            this.btnRead1 = new System.Windows.Forms.Button();
            this.addr0 = new System.Windows.Forms.TextBox();
            this.btnWrite7 = new System.Windows.Forms.Button();
            this.btnRead3 = new System.Windows.Forms.Button();
            this.btnRead4 = new System.Windows.Forms.Button();
            this.btnRead5 = new System.Windows.Forms.Button();
            this.btnRead6 = new System.Windows.Forms.Button();
            this.btnRead7 = new System.Windows.Forms.Button();
            this.btnWrite8 = new System.Windows.Forms.Button();
            this.btnRead8 = new System.Windows.Forms.Button();
            this.btnWrite9 = new System.Windows.Forms.Button();
            this.btnRead9 = new System.Windows.Forms.Button();
            this.btnWrite10 = new System.Windows.Forms.Button();
            this.btnRead10 = new System.Windows.Forms.Button();
            this.btnWrite11 = new System.Windows.Forms.Button();
            this.btnRead11 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.reg0 = new System.Windows.Forms.NumericUpDown();
            this.btnReadAll = new System.Windows.Forms.Button();
            this.btnWriteAll = new System.Windows.Forms.Button();
            this.btnSaveAll = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblServer = new System.Windows.Forms.Label();
            this.txtCameraName = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnSaveAs = new System.Windows.Forms.Button();
            this.lblScreenStatus = new System.Windows.Forms.Label();
            this.tablePanel.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reg11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg0)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tablePanel
            // 
            this.tablePanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tablePanel.ColumnCount = 6;
            this.tablePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tablePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tablePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tablePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tablePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tablePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tablePanel.Controls.Add(this.panel13, 3, 12);
            this.tablePanel.Controls.Add(this.panel12, 3, 11);
            this.tablePanel.Controls.Add(this.panel11, 3, 10);
            this.tablePanel.Controls.Add(this.panel10, 3, 9);
            this.tablePanel.Controls.Add(this.panel9, 3, 8);
            this.tablePanel.Controls.Add(this.panel8, 3, 7);
            this.tablePanel.Controls.Add(this.panel7, 3, 6);
            this.tablePanel.Controls.Add(this.panel6, 3, 5);
            this.tablePanel.Controls.Add(this.panel5, 3, 4);
            this.tablePanel.Controls.Add(this.panel4, 3, 3);
            this.tablePanel.Controls.Add(this.panel3, 3, 2);
            this.tablePanel.Controls.Add(this.panel2, 3, 1);
            this.tablePanel.Controls.Add(this.reg11, 1, 12);
            this.tablePanel.Controls.Add(this.reg10, 1, 11);
            this.tablePanel.Controls.Add(this.reg9, 1, 10);
            this.tablePanel.Controls.Add(this.reg8, 1, 9);
            this.tablePanel.Controls.Add(this.reg7, 1, 8);
            this.tablePanel.Controls.Add(this.reg6, 1, 7);
            this.tablePanel.Controls.Add(this.reg5, 1, 6);
            this.tablePanel.Controls.Add(this.reg4, 1, 5);
            this.tablePanel.Controls.Add(this.reg3, 1, 4);
            this.tablePanel.Controls.Add(this.reg2, 1, 3);
            this.tablePanel.Controls.Add(this.reg1, 1, 2);
            this.tablePanel.Controls.Add(this.addr11, 2, 12);
            this.tablePanel.Controls.Add(this.addr10, 2, 11);
            this.tablePanel.Controls.Add(this.addr9, 2, 10);
            this.tablePanel.Controls.Add(this.addr8, 2, 9);
            this.tablePanel.Controls.Add(this.addr7, 2, 8);
            this.tablePanel.Controls.Add(this.addr6, 2, 7);
            this.tablePanel.Controls.Add(this.addr5, 2, 6);
            this.tablePanel.Controls.Add(this.addr4, 2, 5);
            this.tablePanel.Controls.Add(this.addr3, 2, 4);
            this.tablePanel.Controls.Add(this.btnRead2, 5, 3);
            this.tablePanel.Controls.Add(this.addr2, 2, 3);
            this.tablePanel.Controls.Add(this.addr1, 2, 2);
            this.tablePanel.Controls.Add(this.label2, 5, 0);
            this.tablePanel.Controls.Add(this.label1, 4, 0);
            this.tablePanel.Controls.Add(this.label5, 2, 0);
            this.tablePanel.Controls.Add(this.label4, 0, 0);
            this.tablePanel.Controls.Add(this.btnRead0, 5, 1);
            this.tablePanel.Controls.Add(this.btnWrite0, 4, 1);
            this.tablePanel.Controls.Add(this.label3, 3, 0);
            this.tablePanel.Controls.Add(this.btnWrite1, 4, 2);
            this.tablePanel.Controls.Add(this.label6, 0, 1);
            this.tablePanel.Controls.Add(this.label8, 0, 2);
            this.tablePanel.Controls.Add(this.label7, 0, 3);
            this.tablePanel.Controls.Add(this.label9, 0, 4);
            this.tablePanel.Controls.Add(this.label10, 0, 5);
            this.tablePanel.Controls.Add(this.label11, 0, 6);
            this.tablePanel.Controls.Add(this.label12, 0, 7);
            this.tablePanel.Controls.Add(this.label13, 0, 8);
            this.tablePanel.Controls.Add(this.label14, 0, 9);
            this.tablePanel.Controls.Add(this.label15, 0, 10);
            this.tablePanel.Controls.Add(this.label16, 0, 11);
            this.tablePanel.Controls.Add(this.label17, 0, 12);
            this.tablePanel.Controls.Add(this.btnWrite2, 4, 3);
            this.tablePanel.Controls.Add(this.btnWrite3, 4, 4);
            this.tablePanel.Controls.Add(this.btnWrite4, 4, 5);
            this.tablePanel.Controls.Add(this.btnWrite5, 4, 6);
            this.tablePanel.Controls.Add(this.btnWrite6, 4, 7);
            this.tablePanel.Controls.Add(this.btnRead1, 5, 2);
            this.tablePanel.Controls.Add(this.addr0, 2, 1);
            this.tablePanel.Controls.Add(this.btnWrite7, 4, 8);
            this.tablePanel.Controls.Add(this.btnRead3, 5, 4);
            this.tablePanel.Controls.Add(this.btnRead4, 5, 5);
            this.tablePanel.Controls.Add(this.btnRead5, 5, 6);
            this.tablePanel.Controls.Add(this.btnRead6, 5, 7);
            this.tablePanel.Controls.Add(this.btnRead7, 5, 8);
            this.tablePanel.Controls.Add(this.btnWrite8, 4, 9);
            this.tablePanel.Controls.Add(this.btnRead8, 5, 9);
            this.tablePanel.Controls.Add(this.btnWrite9, 4, 10);
            this.tablePanel.Controls.Add(this.btnRead9, 5, 10);
            this.tablePanel.Controls.Add(this.btnWrite10, 4, 11);
            this.tablePanel.Controls.Add(this.btnRead10, 5, 11);
            this.tablePanel.Controls.Add(this.btnWrite11, 4, 12);
            this.tablePanel.Controls.Add(this.btnRead11, 5, 12);
            this.tablePanel.Controls.Add(this.label19, 1, 0);
            this.tablePanel.Controls.Add(this.reg0, 1, 1);
            this.tablePanel.Location = new System.Drawing.Point(12, 106);
            this.tablePanel.Name = "tablePanel";
            this.tablePanel.RowCount = 13;
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tablePanel.Size = new System.Drawing.Size(729, 404);
            this.tablePanel.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.val11);
            this.panel13.Controls.Add(this.add11);
            this.panel13.Controls.Add(this.sub11);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(393, 376);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(230, 24);
            this.panel13.TabIndex = 92;
            // 
            // val11
            // 
            this.val11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val11.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val11.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val11.Location = new System.Drawing.Point(40, 0);
            this.val11.Name = "val11";
            this.val11.Size = new System.Drawing.Size(155, 23);
            this.val11.TabIndex = 30;
            this.val11.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val11_KeyUp);
            // 
            // add11
            // 
            this.add11.Dock = System.Windows.Forms.DockStyle.Right;
            this.add11.Location = new System.Drawing.Point(195, 0);
            this.add11.Name = "add11";
            this.add11.Size = new System.Drawing.Size(35, 24);
            this.add11.TabIndex = 32;
            this.add11.Text = "+";
            this.add11.UseVisualStyleBackColor = true;
            this.add11.Click += new System.EventHandler(this.add11_Click);
            // 
            // sub11
            // 
            this.sub11.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub11.Location = new System.Drawing.Point(0, 0);
            this.sub11.Name = "sub11";
            this.sub11.Size = new System.Drawing.Size(40, 24);
            this.sub11.TabIndex = 31;
            this.sub11.Text = "-";
            this.sub11.UseVisualStyleBackColor = true;
            this.sub11.Click += new System.EventHandler(this.sub11_Click);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.val10);
            this.panel12.Controls.Add(this.add10);
            this.panel12.Controls.Add(this.sub10);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(393, 345);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(230, 24);
            this.panel12.TabIndex = 91;
            // 
            // val10
            // 
            this.val10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val10.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val10.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val10.Location = new System.Drawing.Point(40, 0);
            this.val10.Name = "val10";
            this.val10.Size = new System.Drawing.Size(155, 23);
            this.val10.TabIndex = 30;
            this.val10.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val10_KeyUp);
            // 
            // add10
            // 
            this.add10.Dock = System.Windows.Forms.DockStyle.Right;
            this.add10.Location = new System.Drawing.Point(195, 0);
            this.add10.Name = "add10";
            this.add10.Size = new System.Drawing.Size(35, 24);
            this.add10.TabIndex = 32;
            this.add10.Text = "+";
            this.add10.UseVisualStyleBackColor = true;
            this.add10.Click += new System.EventHandler(this.add10_Click);
            // 
            // sub10
            // 
            this.sub10.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub10.Location = new System.Drawing.Point(0, 0);
            this.sub10.Name = "sub10";
            this.sub10.Size = new System.Drawing.Size(40, 24);
            this.sub10.TabIndex = 31;
            this.sub10.Text = "-";
            this.sub10.UseVisualStyleBackColor = true;
            this.sub10.Click += new System.EventHandler(this.sub10_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.val9);
            this.panel11.Controls.Add(this.add9);
            this.panel11.Controls.Add(this.sub9);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(393, 314);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(230, 24);
            this.panel11.TabIndex = 90;
            // 
            // val9
            // 
            this.val9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val9.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val9.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val9.Location = new System.Drawing.Point(40, 0);
            this.val9.Name = "val9";
            this.val9.Size = new System.Drawing.Size(155, 23);
            this.val9.TabIndex = 30;
            this.val9.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val9_KeyUp);
            // 
            // add9
            // 
            this.add9.Dock = System.Windows.Forms.DockStyle.Right;
            this.add9.Location = new System.Drawing.Point(195, 0);
            this.add9.Name = "add9";
            this.add9.Size = new System.Drawing.Size(35, 24);
            this.add9.TabIndex = 32;
            this.add9.Text = "+";
            this.add9.UseVisualStyleBackColor = true;
            this.add9.Click += new System.EventHandler(this.add9_Click);
            // 
            // sub9
            // 
            this.sub9.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub9.Location = new System.Drawing.Point(0, 0);
            this.sub9.Name = "sub9";
            this.sub9.Size = new System.Drawing.Size(40, 24);
            this.sub9.TabIndex = 31;
            this.sub9.Text = "-";
            this.sub9.UseVisualStyleBackColor = true;
            this.sub9.Click += new System.EventHandler(this.sub9_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.val8);
            this.panel10.Controls.Add(this.add8);
            this.panel10.Controls.Add(this.sub8);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(393, 283);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(230, 24);
            this.panel10.TabIndex = 89;
            // 
            // val8
            // 
            this.val8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val8.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val8.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val8.Location = new System.Drawing.Point(40, 0);
            this.val8.Name = "val8";
            this.val8.Size = new System.Drawing.Size(155, 23);
            this.val8.TabIndex = 30;
            this.val8.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val8_KeyUp);
            // 
            // add8
            // 
            this.add8.Dock = System.Windows.Forms.DockStyle.Right;
            this.add8.Location = new System.Drawing.Point(195, 0);
            this.add8.Name = "add8";
            this.add8.Size = new System.Drawing.Size(35, 24);
            this.add8.TabIndex = 32;
            this.add8.Text = "+";
            this.add8.UseVisualStyleBackColor = true;
            this.add8.Click += new System.EventHandler(this.add8_Click);
            // 
            // sub8
            // 
            this.sub8.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub8.Location = new System.Drawing.Point(0, 0);
            this.sub8.Name = "sub8";
            this.sub8.Size = new System.Drawing.Size(40, 24);
            this.sub8.TabIndex = 31;
            this.sub8.Text = "-";
            this.sub8.UseVisualStyleBackColor = true;
            this.sub8.Click += new System.EventHandler(this.sub8_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.val7);
            this.panel9.Controls.Add(this.add7);
            this.panel9.Controls.Add(this.sub7);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(393, 252);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(230, 24);
            this.panel9.TabIndex = 88;
            // 
            // val7
            // 
            this.val7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val7.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val7.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val7.Location = new System.Drawing.Point(40, 0);
            this.val7.Name = "val7";
            this.val7.Size = new System.Drawing.Size(155, 23);
            this.val7.TabIndex = 30;
            this.val7.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val7_KeyUp);
            // 
            // add7
            // 
            this.add7.Dock = System.Windows.Forms.DockStyle.Right;
            this.add7.Location = new System.Drawing.Point(195, 0);
            this.add7.Name = "add7";
            this.add7.Size = new System.Drawing.Size(35, 24);
            this.add7.TabIndex = 32;
            this.add7.Text = "+";
            this.add7.UseVisualStyleBackColor = true;
            this.add7.Click += new System.EventHandler(this.add7_Click);
            // 
            // sub7
            // 
            this.sub7.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub7.Location = new System.Drawing.Point(0, 0);
            this.sub7.Name = "sub7";
            this.sub7.Size = new System.Drawing.Size(40, 24);
            this.sub7.TabIndex = 31;
            this.sub7.Text = "-";
            this.sub7.UseVisualStyleBackColor = true;
            this.sub7.Click += new System.EventHandler(this.sub7_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.val6);
            this.panel8.Controls.Add(this.add6);
            this.panel8.Controls.Add(this.sub6);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(393, 221);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(230, 24);
            this.panel8.TabIndex = 87;
            // 
            // val6
            // 
            this.val6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val6.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val6.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val6.Location = new System.Drawing.Point(40, 0);
            this.val6.Name = "val6";
            this.val6.Size = new System.Drawing.Size(155, 23);
            this.val6.TabIndex = 30;
            this.val6.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val6_KeyUp);
            // 
            // add6
            // 
            this.add6.Dock = System.Windows.Forms.DockStyle.Right;
            this.add6.Location = new System.Drawing.Point(195, 0);
            this.add6.Name = "add6";
            this.add6.Size = new System.Drawing.Size(35, 24);
            this.add6.TabIndex = 32;
            this.add6.Text = "+";
            this.add6.UseVisualStyleBackColor = true;
            this.add6.Click += new System.EventHandler(this.add6_Click);
            // 
            // sub6
            // 
            this.sub6.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub6.Location = new System.Drawing.Point(0, 0);
            this.sub6.Name = "sub6";
            this.sub6.Size = new System.Drawing.Size(40, 24);
            this.sub6.TabIndex = 31;
            this.sub6.Text = "-";
            this.sub6.UseVisualStyleBackColor = true;
            this.sub6.Click += new System.EventHandler(this.sub6_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.val5);
            this.panel7.Controls.Add(this.add5);
            this.panel7.Controls.Add(this.sub5);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(393, 190);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(230, 24);
            this.panel7.TabIndex = 86;
            // 
            // val5
            // 
            this.val5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val5.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val5.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val5.Location = new System.Drawing.Point(40, 0);
            this.val5.Name = "val5";
            this.val5.Size = new System.Drawing.Size(155, 23);
            this.val5.TabIndex = 30;
            this.val5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val5_KeyUp);
            // 
            // add5
            // 
            this.add5.Dock = System.Windows.Forms.DockStyle.Right;
            this.add5.Location = new System.Drawing.Point(195, 0);
            this.add5.Name = "add5";
            this.add5.Size = new System.Drawing.Size(35, 24);
            this.add5.TabIndex = 32;
            this.add5.Text = "+";
            this.add5.UseVisualStyleBackColor = true;
            this.add5.Click += new System.EventHandler(this.add5_Click);
            // 
            // sub5
            // 
            this.sub5.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub5.Location = new System.Drawing.Point(0, 0);
            this.sub5.Name = "sub5";
            this.sub5.Size = new System.Drawing.Size(40, 24);
            this.sub5.TabIndex = 31;
            this.sub5.Text = "-";
            this.sub5.UseVisualStyleBackColor = true;
            this.sub5.Click += new System.EventHandler(this.sub5_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.val4);
            this.panel6.Controls.Add(this.add4);
            this.panel6.Controls.Add(this.sub4);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(393, 159);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(230, 24);
            this.panel6.TabIndex = 85;
            // 
            // val4
            // 
            this.val4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val4.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val4.Location = new System.Drawing.Point(40, 0);
            this.val4.Name = "val4";
            this.val4.Size = new System.Drawing.Size(155, 23);
            this.val4.TabIndex = 30;
            this.val4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val4_KeyUp);
            // 
            // add4
            // 
            this.add4.Dock = System.Windows.Forms.DockStyle.Right;
            this.add4.Location = new System.Drawing.Point(195, 0);
            this.add4.Name = "add4";
            this.add4.Size = new System.Drawing.Size(35, 24);
            this.add4.TabIndex = 32;
            this.add4.Text = "+";
            this.add4.UseVisualStyleBackColor = true;
            this.add4.Click += new System.EventHandler(this.add4_Click);
            // 
            // sub4
            // 
            this.sub4.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub4.Location = new System.Drawing.Point(0, 0);
            this.sub4.Name = "sub4";
            this.sub4.Size = new System.Drawing.Size(40, 24);
            this.sub4.TabIndex = 31;
            this.sub4.Text = "-";
            this.sub4.UseVisualStyleBackColor = true;
            this.sub4.Click += new System.EventHandler(this.sub4_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.val3);
            this.panel5.Controls.Add(this.add3);
            this.panel5.Controls.Add(this.sub3);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(393, 128);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(230, 24);
            this.panel5.TabIndex = 84;
            // 
            // val3
            // 
            this.val3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val3.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val3.Location = new System.Drawing.Point(40, 0);
            this.val3.Name = "val3";
            this.val3.Size = new System.Drawing.Size(155, 23);
            this.val3.TabIndex = 30;
            this.val3.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val3_KeyUp);
            // 
            // add3
            // 
            this.add3.Dock = System.Windows.Forms.DockStyle.Right;
            this.add3.Location = new System.Drawing.Point(195, 0);
            this.add3.Name = "add3";
            this.add3.Size = new System.Drawing.Size(35, 24);
            this.add3.TabIndex = 32;
            this.add3.Text = "+";
            this.add3.UseVisualStyleBackColor = true;
            this.add3.Click += new System.EventHandler(this.add3_Click);
            // 
            // sub3
            // 
            this.sub3.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub3.Location = new System.Drawing.Point(0, 0);
            this.sub3.Name = "sub3";
            this.sub3.Size = new System.Drawing.Size(40, 24);
            this.sub3.TabIndex = 31;
            this.sub3.Text = "-";
            this.sub3.UseVisualStyleBackColor = true;
            this.sub3.Click += new System.EventHandler(this.sub3_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.val2);
            this.panel4.Controls.Add(this.add2);
            this.panel4.Controls.Add(this.sub2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(393, 97);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(230, 24);
            this.panel4.TabIndex = 83;
            // 
            // val2
            // 
            this.val2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val2.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val2.Location = new System.Drawing.Point(40, 0);
            this.val2.Name = "val2";
            this.val2.Size = new System.Drawing.Size(155, 23);
            this.val2.TabIndex = 30;
            this.val2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val2_KeyUp);
            // 
            // add2
            // 
            this.add2.Dock = System.Windows.Forms.DockStyle.Right;
            this.add2.Location = new System.Drawing.Point(195, 0);
            this.add2.Name = "add2";
            this.add2.Size = new System.Drawing.Size(35, 24);
            this.add2.TabIndex = 32;
            this.add2.Text = "+";
            this.add2.UseVisualStyleBackColor = true;
            this.add2.Click += new System.EventHandler(this.add2_Click);
            // 
            // sub2
            // 
            this.sub2.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub2.Location = new System.Drawing.Point(0, 0);
            this.sub2.Name = "sub2";
            this.sub2.Size = new System.Drawing.Size(40, 24);
            this.sub2.TabIndex = 31;
            this.sub2.Text = "-";
            this.sub2.UseVisualStyleBackColor = true;
            this.sub2.Click += new System.EventHandler(this.sub2_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.val1);
            this.panel3.Controls.Add(this.add1);
            this.panel3.Controls.Add(this.sub1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(393, 66);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(230, 24);
            this.panel3.TabIndex = 82;
            // 
            // val1
            // 
            this.val1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val1.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val1.Location = new System.Drawing.Point(40, 0);
            this.val1.Name = "val1";
            this.val1.Size = new System.Drawing.Size(155, 23);
            this.val1.TabIndex = 30;
            this.val1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val1_KeyUp);
            // 
            // add1
            // 
            this.add1.Dock = System.Windows.Forms.DockStyle.Right;
            this.add1.Location = new System.Drawing.Point(195, 0);
            this.add1.Name = "add1";
            this.add1.Size = new System.Drawing.Size(35, 24);
            this.add1.TabIndex = 32;
            this.add1.Text = "+";
            this.add1.UseVisualStyleBackColor = true;
            this.add1.Click += new System.EventHandler(this.add1_Click);
            // 
            // sub1
            // 
            this.sub1.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub1.Location = new System.Drawing.Point(0, 0);
            this.sub1.Name = "sub1";
            this.sub1.Size = new System.Drawing.Size(40, 24);
            this.sub1.TabIndex = 31;
            this.sub1.Text = "-";
            this.sub1.UseVisualStyleBackColor = true;
            this.sub1.Click += new System.EventHandler(this.sub1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.val0);
            this.panel2.Controls.Add(this.add0);
            this.panel2.Controls.Add(this.sub0);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(393, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(230, 24);
            this.panel2.TabIndex = 31;
            // 
            // val0
            // 
            this.val0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val0.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.val0.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.val0.Location = new System.Drawing.Point(40, 0);
            this.val0.Name = "val0";
            this.val0.Size = new System.Drawing.Size(155, 23);
            this.val0.TabIndex = 30;
            this.val0.KeyUp += new System.Windows.Forms.KeyEventHandler(this.val0_KeyUp);
            // 
            // add0
            // 
            this.add0.Dock = System.Windows.Forms.DockStyle.Right;
            this.add0.Location = new System.Drawing.Point(195, 0);
            this.add0.Name = "add0";
            this.add0.Size = new System.Drawing.Size(35, 24);
            this.add0.TabIndex = 32;
            this.add0.Text = "+";
            this.add0.UseVisualStyleBackColor = true;
            this.add0.Click += new System.EventHandler(this.add0_Click);
            // 
            // sub0
            // 
            this.sub0.Dock = System.Windows.Forms.DockStyle.Left;
            this.sub0.Location = new System.Drawing.Point(0, 0);
            this.sub0.Name = "sub0";
            this.sub0.Size = new System.Drawing.Size(40, 24);
            this.sub0.TabIndex = 31;
            this.sub0.Text = "-";
            this.sub0.UseVisualStyleBackColor = true;
            this.sub0.Click += new System.EventHandler(this.sub0_Click);
            // 
            // reg11
            // 
            this.reg11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg11.Enabled = false;
            this.reg11.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg11.Location = new System.Drawing.Point(105, 376);
            this.reg11.Name = "reg11";
            this.reg11.Size = new System.Drawing.Size(44, 23);
            this.reg11.TabIndex = 81;
            this.reg11.Value = new decimal(new int[] {
            11,
            0,
            0,
            0});
            // 
            // reg10
            // 
            this.reg10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg10.Enabled = false;
            this.reg10.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg10.Location = new System.Drawing.Point(105, 345);
            this.reg10.Name = "reg10";
            this.reg10.Size = new System.Drawing.Size(44, 23);
            this.reg10.TabIndex = 80;
            this.reg10.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // reg9
            // 
            this.reg9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg9.Enabled = false;
            this.reg9.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg9.Location = new System.Drawing.Point(105, 314);
            this.reg9.Name = "reg9";
            this.reg9.Size = new System.Drawing.Size(44, 23);
            this.reg9.TabIndex = 79;
            this.reg9.Value = new decimal(new int[] {
            9,
            0,
            0,
            0});
            // 
            // reg8
            // 
            this.reg8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg8.Enabled = false;
            this.reg8.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg8.Location = new System.Drawing.Point(105, 283);
            this.reg8.Name = "reg8";
            this.reg8.Size = new System.Drawing.Size(44, 23);
            this.reg8.TabIndex = 78;
            this.reg8.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // reg7
            // 
            this.reg7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg7.Enabled = false;
            this.reg7.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg7.Location = new System.Drawing.Point(105, 252);
            this.reg7.Name = "reg7";
            this.reg7.Size = new System.Drawing.Size(44, 23);
            this.reg7.TabIndex = 77;
            this.reg7.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            // 
            // reg6
            // 
            this.reg6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg6.Enabled = false;
            this.reg6.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg6.Location = new System.Drawing.Point(105, 221);
            this.reg6.Name = "reg6";
            this.reg6.Size = new System.Drawing.Size(44, 23);
            this.reg6.TabIndex = 76;
            this.reg6.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // reg5
            // 
            this.reg5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg5.Enabled = false;
            this.reg5.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg5.Location = new System.Drawing.Point(105, 190);
            this.reg5.Name = "reg5";
            this.reg5.Size = new System.Drawing.Size(44, 23);
            this.reg5.TabIndex = 75;
            this.reg5.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // reg4
            // 
            this.reg4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg4.Enabled = false;
            this.reg4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg4.Location = new System.Drawing.Point(105, 159);
            this.reg4.Name = "reg4";
            this.reg4.Size = new System.Drawing.Size(44, 23);
            this.reg4.TabIndex = 74;
            this.reg4.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // reg3
            // 
            this.reg3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg3.Enabled = false;
            this.reg3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg3.Location = new System.Drawing.Point(105, 128);
            this.reg3.Name = "reg3";
            this.reg3.Size = new System.Drawing.Size(44, 23);
            this.reg3.TabIndex = 73;
            this.reg3.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // reg2
            // 
            this.reg2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg2.Enabled = false;
            this.reg2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg2.Location = new System.Drawing.Point(105, 97);
            this.reg2.Name = "reg2";
            this.reg2.Size = new System.Drawing.Size(44, 23);
            this.reg2.TabIndex = 72;
            this.reg2.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // reg1
            // 
            this.reg1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg1.Enabled = false;
            this.reg1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg1.Location = new System.Drawing.Point(105, 66);
            this.reg1.Name = "reg1";
            this.reg1.Size = new System.Drawing.Size(44, 23);
            this.reg1.TabIndex = 71;
            this.reg1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // addr11
            // 
            this.addr11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr11.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr11.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr11.Location = new System.Drawing.Point(156, 376);
            this.addr11.Name = "addr11";
            this.addr11.Size = new System.Drawing.Size(230, 23);
            this.addr11.TabIndex = 66;
            // 
            // addr10
            // 
            this.addr10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr10.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr10.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr10.Location = new System.Drawing.Point(156, 345);
            this.addr10.Name = "addr10";
            this.addr10.Size = new System.Drawing.Size(230, 23);
            this.addr10.TabIndex = 64;
            // 
            // addr9
            // 
            this.addr9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr9.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr9.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr9.Location = new System.Drawing.Point(156, 314);
            this.addr9.Name = "addr9";
            this.addr9.Size = new System.Drawing.Size(230, 23);
            this.addr9.TabIndex = 62;
            // 
            // addr8
            // 
            this.addr8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr8.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr8.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr8.Location = new System.Drawing.Point(156, 283);
            this.addr8.Name = "addr8";
            this.addr8.Size = new System.Drawing.Size(230, 23);
            this.addr8.TabIndex = 60;
            // 
            // addr7
            // 
            this.addr7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr7.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr7.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr7.Location = new System.Drawing.Point(156, 252);
            this.addr7.Name = "addr7";
            this.addr7.Size = new System.Drawing.Size(230, 23);
            this.addr7.TabIndex = 58;
            // 
            // addr6
            // 
            this.addr6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr6.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr6.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr6.Location = new System.Drawing.Point(156, 221);
            this.addr6.Name = "addr6";
            this.addr6.Size = new System.Drawing.Size(230, 23);
            this.addr6.TabIndex = 56;
            // 
            // addr5
            // 
            this.addr5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr5.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr5.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr5.Location = new System.Drawing.Point(156, 190);
            this.addr5.Name = "addr5";
            this.addr5.Size = new System.Drawing.Size(230, 23);
            this.addr5.TabIndex = 54;
            // 
            // addr4
            // 
            this.addr4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr4.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr4.Location = new System.Drawing.Point(156, 159);
            this.addr4.Name = "addr4";
            this.addr4.Size = new System.Drawing.Size(230, 23);
            this.addr4.TabIndex = 52;
            // 
            // addr3
            // 
            this.addr3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr3.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr3.Location = new System.Drawing.Point(156, 128);
            this.addr3.Name = "addr3";
            this.addr3.Size = new System.Drawing.Size(230, 23);
            this.addr3.TabIndex = 38;
            // 
            // btnRead2
            // 
            this.btnRead2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead2.Location = new System.Drawing.Point(680, 96);
            this.btnRead2.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead2.Name = "btnRead2";
            this.btnRead2.Size = new System.Drawing.Size(46, 26);
            this.btnRead2.TabIndex = 35;
            this.btnRead2.Text = "读";
            this.btnRead2.UseVisualStyleBackColor = true;
            this.btnRead2.Click += new System.EventHandler(this.btnRead2_Click);
            // 
            // addr2
            // 
            this.addr2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr2.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr2.Location = new System.Drawing.Point(156, 97);
            this.addr2.Name = "addr2";
            this.addr2.Size = new System.Drawing.Size(230, 23);
            this.addr2.TabIndex = 33;
            // 
            // addr1
            // 
            this.addr1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr1.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr1.Location = new System.Drawing.Point(156, 66);
            this.addr1.Name = "addr1";
            this.addr1.Size = new System.Drawing.Size(230, 23);
            this.addr1.TabIndex = 31;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(681, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 30);
            this.label2.TabIndex = 8;
            this.label2.Text = "读取";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(630, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 30);
            this.label1.TabIndex = 7;
            this.label1.Text = "写入";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(156, 1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(230, 30);
            this.label5.TabIndex = 6;
            this.label5.Text = "寄存器地址";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(4, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 30);
            this.label4.TabIndex = 5;
            this.label4.Text = "寄存器";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnRead0
            // 
            this.btnRead0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead0.Location = new System.Drawing.Point(680, 34);
            this.btnRead0.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead0.Name = "btnRead0";
            this.btnRead0.Size = new System.Drawing.Size(46, 26);
            this.btnRead0.TabIndex = 1;
            this.btnRead0.Text = "读";
            this.btnRead0.UseVisualStyleBackColor = true;
            this.btnRead0.Click += new System.EventHandler(this.btnRead0_Click);
            // 
            // btnWrite0
            // 
            this.btnWrite0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite0.Location = new System.Drawing.Point(629, 34);
            this.btnWrite0.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite0.Name = "btnWrite0";
            this.btnWrite0.Size = new System.Drawing.Size(46, 26);
            this.btnWrite0.TabIndex = 0;
            this.btnWrite0.Text = "写";
            this.btnWrite0.UseVisualStyleBackColor = true;
            this.btnWrite0.Click += new System.EventHandler(this.btnWrite0_Click);
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(393, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(230, 30);
            this.label3.TabIndex = 4;
            this.label3.Text = "寄存器值(十六进制)";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnWrite1
            // 
            this.btnWrite1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite1.Location = new System.Drawing.Point(629, 65);
            this.btnWrite1.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite1.Name = "btnWrite1";
            this.btnWrite1.Size = new System.Drawing.Size(46, 26);
            this.btnWrite1.TabIndex = 12;
            this.btnWrite1.Text = "写";
            this.btnWrite1.UseVisualStyleBackColor = true;
            this.btnWrite1.Click += new System.EventHandler(this.btnWrite1_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(4, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 30);
            this.label6.TabIndex = 9;
            this.label6.Text = "寄存器";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(4, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 30);
            this.label8.TabIndex = 11;
            this.label8.Text = "寄存器";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(4, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 30);
            this.label7.TabIndex = 13;
            this.label7.Text = "寄存器";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(4, 125);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 30);
            this.label9.TabIndex = 14;
            this.label9.Text = "寄存器";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(4, 156);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 30);
            this.label10.TabIndex = 15;
            this.label10.Text = "寄存器";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(4, 187);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 30);
            this.label11.TabIndex = 16;
            this.label11.Text = "寄存器";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(4, 218);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 30);
            this.label12.TabIndex = 17;
            this.label12.Text = "寄存器";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(4, 249);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 30);
            this.label13.TabIndex = 18;
            this.label13.Text = "寄存器";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(4, 280);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 30);
            this.label14.TabIndex = 19;
            this.label14.Text = "寄存器";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(4, 311);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(94, 30);
            this.label15.TabIndex = 20;
            this.label15.Text = "寄存器";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(4, 342);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 30);
            this.label16.TabIndex = 21;
            this.label16.Text = "寄存器";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(4, 373);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 30);
            this.label17.TabIndex = 22;
            this.label17.Text = "寄存器";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnWrite2
            // 
            this.btnWrite2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite2.Location = new System.Drawing.Point(629, 96);
            this.btnWrite2.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite2.Name = "btnWrite2";
            this.btnWrite2.Size = new System.Drawing.Size(46, 26);
            this.btnWrite2.TabIndex = 23;
            this.btnWrite2.Text = "写";
            this.btnWrite2.UseVisualStyleBackColor = true;
            this.btnWrite2.Click += new System.EventHandler(this.btnWrite2_Click);
            // 
            // btnWrite3
            // 
            this.btnWrite3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite3.Location = new System.Drawing.Point(629, 127);
            this.btnWrite3.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite3.Name = "btnWrite3";
            this.btnWrite3.Size = new System.Drawing.Size(46, 26);
            this.btnWrite3.TabIndex = 24;
            this.btnWrite3.Text = "写";
            this.btnWrite3.UseVisualStyleBackColor = true;
            this.btnWrite3.Click += new System.EventHandler(this.btnWrite3_Click);
            // 
            // btnWrite4
            // 
            this.btnWrite4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite4.Location = new System.Drawing.Point(629, 158);
            this.btnWrite4.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite4.Name = "btnWrite4";
            this.btnWrite4.Size = new System.Drawing.Size(46, 26);
            this.btnWrite4.TabIndex = 25;
            this.btnWrite4.Text = "写";
            this.btnWrite4.UseVisualStyleBackColor = true;
            this.btnWrite4.Click += new System.EventHandler(this.btnWrite4_Click);
            // 
            // btnWrite5
            // 
            this.btnWrite5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite5.Location = new System.Drawing.Point(629, 189);
            this.btnWrite5.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite5.Name = "btnWrite5";
            this.btnWrite5.Size = new System.Drawing.Size(46, 26);
            this.btnWrite5.TabIndex = 26;
            this.btnWrite5.Text = "写";
            this.btnWrite5.UseVisualStyleBackColor = true;
            this.btnWrite5.Click += new System.EventHandler(this.btnWrite5_Click);
            // 
            // btnWrite6
            // 
            this.btnWrite6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite6.Location = new System.Drawing.Point(629, 220);
            this.btnWrite6.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite6.Name = "btnWrite6";
            this.btnWrite6.Size = new System.Drawing.Size(46, 26);
            this.btnWrite6.TabIndex = 27;
            this.btnWrite6.Text = "写";
            this.btnWrite6.UseVisualStyleBackColor = true;
            this.btnWrite6.Click += new System.EventHandler(this.btnWrite6_Click);
            // 
            // btnRead1
            // 
            this.btnRead1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead1.Location = new System.Drawing.Point(680, 65);
            this.btnRead1.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead1.Name = "btnRead1";
            this.btnRead1.Size = new System.Drawing.Size(46, 26);
            this.btnRead1.TabIndex = 28;
            this.btnRead1.Text = "读";
            this.btnRead1.UseVisualStyleBackColor = true;
            this.btnRead1.Click += new System.EventHandler(this.btnRead1_Click);
            // 
            // addr0
            // 
            this.addr0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addr0.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addr0.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.addr0.Location = new System.Drawing.Point(156, 35);
            this.addr0.Name = "addr0";
            this.addr0.Size = new System.Drawing.Size(230, 23);
            this.addr0.TabIndex = 29;
            // 
            // btnWrite7
            // 
            this.btnWrite7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite7.Location = new System.Drawing.Point(629, 251);
            this.btnWrite7.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite7.Name = "btnWrite7";
            this.btnWrite7.Size = new System.Drawing.Size(46, 26);
            this.btnWrite7.TabIndex = 36;
            this.btnWrite7.Text = "写";
            this.btnWrite7.UseVisualStyleBackColor = true;
            this.btnWrite7.Click += new System.EventHandler(this.btnWrite7_Click);
            // 
            // btnRead3
            // 
            this.btnRead3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead3.Location = new System.Drawing.Point(680, 127);
            this.btnRead3.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead3.Name = "btnRead3";
            this.btnRead3.Size = new System.Drawing.Size(46, 26);
            this.btnRead3.TabIndex = 37;
            this.btnRead3.Text = "读";
            this.btnRead3.UseVisualStyleBackColor = true;
            this.btnRead3.Click += new System.EventHandler(this.btnRead3_Click);
            // 
            // btnRead4
            // 
            this.btnRead4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead4.Location = new System.Drawing.Point(680, 158);
            this.btnRead4.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead4.Name = "btnRead4";
            this.btnRead4.Size = new System.Drawing.Size(46, 26);
            this.btnRead4.TabIndex = 39;
            this.btnRead4.Text = "读";
            this.btnRead4.UseVisualStyleBackColor = true;
            this.btnRead4.Click += new System.EventHandler(this.btnRead4_Click);
            // 
            // btnRead5
            // 
            this.btnRead5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead5.Location = new System.Drawing.Point(680, 189);
            this.btnRead5.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead5.Name = "btnRead5";
            this.btnRead5.Size = new System.Drawing.Size(46, 26);
            this.btnRead5.TabIndex = 40;
            this.btnRead5.Text = "读";
            this.btnRead5.UseVisualStyleBackColor = true;
            this.btnRead5.Click += new System.EventHandler(this.btnRead5_Click);
            // 
            // btnRead6
            // 
            this.btnRead6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead6.Location = new System.Drawing.Point(680, 220);
            this.btnRead6.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead6.Name = "btnRead6";
            this.btnRead6.Size = new System.Drawing.Size(46, 26);
            this.btnRead6.TabIndex = 41;
            this.btnRead6.Text = "读";
            this.btnRead6.UseVisualStyleBackColor = true;
            this.btnRead6.Click += new System.EventHandler(this.btnRead6_Click);
            // 
            // btnRead7
            // 
            this.btnRead7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead7.Location = new System.Drawing.Point(680, 251);
            this.btnRead7.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead7.Name = "btnRead7";
            this.btnRead7.Size = new System.Drawing.Size(46, 26);
            this.btnRead7.TabIndex = 42;
            this.btnRead7.Text = "读";
            this.btnRead7.UseVisualStyleBackColor = true;
            this.btnRead7.Click += new System.EventHandler(this.btnRead7_Click);
            // 
            // btnWrite8
            // 
            this.btnWrite8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite8.Location = new System.Drawing.Point(629, 282);
            this.btnWrite8.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite8.Name = "btnWrite8";
            this.btnWrite8.Size = new System.Drawing.Size(46, 26);
            this.btnWrite8.TabIndex = 43;
            this.btnWrite8.Text = "写";
            this.btnWrite8.UseVisualStyleBackColor = true;
            this.btnWrite8.Click += new System.EventHandler(this.btnWrite8_Click);
            // 
            // btnRead8
            // 
            this.btnRead8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead8.Location = new System.Drawing.Point(680, 282);
            this.btnRead8.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead8.Name = "btnRead8";
            this.btnRead8.Size = new System.Drawing.Size(46, 26);
            this.btnRead8.TabIndex = 44;
            this.btnRead8.Text = "读";
            this.btnRead8.UseVisualStyleBackColor = true;
            this.btnRead8.Click += new System.EventHandler(this.btnRead8_Click);
            // 
            // btnWrite9
            // 
            this.btnWrite9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite9.Location = new System.Drawing.Point(629, 313);
            this.btnWrite9.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite9.Name = "btnWrite9";
            this.btnWrite9.Size = new System.Drawing.Size(46, 26);
            this.btnWrite9.TabIndex = 45;
            this.btnWrite9.Text = "写";
            this.btnWrite9.UseVisualStyleBackColor = true;
            this.btnWrite9.Click += new System.EventHandler(this.btnWrite9_Click);
            // 
            // btnRead9
            // 
            this.btnRead9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead9.Location = new System.Drawing.Point(680, 313);
            this.btnRead9.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead9.Name = "btnRead9";
            this.btnRead9.Size = new System.Drawing.Size(46, 26);
            this.btnRead9.TabIndex = 46;
            this.btnRead9.Text = "读";
            this.btnRead9.UseVisualStyleBackColor = true;
            this.btnRead9.Click += new System.EventHandler(this.btnRead9_Click);
            // 
            // btnWrite10
            // 
            this.btnWrite10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite10.Location = new System.Drawing.Point(629, 344);
            this.btnWrite10.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite10.Name = "btnWrite10";
            this.btnWrite10.Size = new System.Drawing.Size(46, 26);
            this.btnWrite10.TabIndex = 47;
            this.btnWrite10.Text = "写";
            this.btnWrite10.UseVisualStyleBackColor = true;
            this.btnWrite10.Click += new System.EventHandler(this.btnWrite10_Click);
            // 
            // btnRead10
            // 
            this.btnRead10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead10.Location = new System.Drawing.Point(680, 344);
            this.btnRead10.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead10.Name = "btnRead10";
            this.btnRead10.Size = new System.Drawing.Size(46, 26);
            this.btnRead10.TabIndex = 48;
            this.btnRead10.Text = "读";
            this.btnRead10.UseVisualStyleBackColor = true;
            this.btnRead10.Click += new System.EventHandler(this.btnRead10_Click);
            // 
            // btnWrite11
            // 
            this.btnWrite11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWrite11.Location = new System.Drawing.Point(629, 375);
            this.btnWrite11.Margin = new System.Windows.Forms.Padding(2);
            this.btnWrite11.Name = "btnWrite11";
            this.btnWrite11.Size = new System.Drawing.Size(46, 26);
            this.btnWrite11.TabIndex = 49;
            this.btnWrite11.Text = "写";
            this.btnWrite11.UseVisualStyleBackColor = true;
            this.btnWrite11.Click += new System.EventHandler(this.btnWrite11_Click);
            // 
            // btnRead11
            // 
            this.btnRead11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRead11.Location = new System.Drawing.Point(680, 375);
            this.btnRead11.Margin = new System.Windows.Forms.Padding(2);
            this.btnRead11.Name = "btnRead11";
            this.btnRead11.Size = new System.Drawing.Size(46, 26);
            this.btnRead11.TabIndex = 50;
            this.btnRead11.Text = "读";
            this.btnRead11.UseVisualStyleBackColor = true;
            this.btnRead11.Click += new System.EventHandler(this.btnRead11_Click);
            // 
            // label19
            // 
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(105, 1);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 30);
            this.label19.TabIndex = 69;
            this.label19.Text = "序号";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // reg0
            // 
            this.reg0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reg0.Enabled = false;
            this.reg0.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.reg0.Location = new System.Drawing.Point(105, 35);
            this.reg0.Name = "reg0";
            this.reg0.Size = new System.Drawing.Size(44, 23);
            this.reg0.TabIndex = 70;
            // 
            // btnReadAll
            // 
            this.btnReadAll.Location = new System.Drawing.Point(9, 50);
            this.btnReadAll.Name = "btnReadAll";
            this.btnReadAll.Size = new System.Drawing.Size(87, 32);
            this.btnReadAll.TabIndex = 1;
            this.btnReadAll.Text = "全读";
            this.btnReadAll.UseVisualStyleBackColor = true;
            this.btnReadAll.Click += new System.EventHandler(this.btnReadAll_Click);
            // 
            // btnWriteAll
            // 
            this.btnWriteAll.Location = new System.Drawing.Point(102, 50);
            this.btnWriteAll.Name = "btnWriteAll";
            this.btnWriteAll.Size = new System.Drawing.Size(87, 32);
            this.btnWriteAll.TabIndex = 2;
            this.btnWriteAll.Text = "全写";
            this.btnWriteAll.UseVisualStyleBackColor = true;
            this.btnWriteAll.Click += new System.EventHandler(this.btnWriteAll_Click);
            // 
            // btnSaveAll
            // 
            this.btnSaveAll.Location = new System.Drawing.Point(195, 50);
            this.btnSaveAll.Name = "btnSaveAll";
            this.btnSaveAll.Size = new System.Drawing.Size(87, 32);
            this.btnSaveAll.TabIndex = 3;
            this.btnSaveAll.Text = "保存至设备";
            this.btnSaveAll.UseVisualStyleBackColor = true;
            this.btnSaveAll.Click += new System.EventHandler(this.btnSaveAll_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(6, 59);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(41, 12);
            this.lblStatus.TabIndex = 6;
            this.lblStatus.Text = "设备IP";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtLog);
            this.groupBox1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(758, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 405);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "日志区:";
            // 
            // txtLog
            // 
            this.txtLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLog.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtLog.Location = new System.Drawing.Point(3, 19);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Size = new System.Drawing.Size(354, 383);
            this.txtLog.TabIndex = 6;
            this.txtLog.WordWrap = false;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(761, 62);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 31);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "清空日志";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblServer
            // 
            this.lblServer.AutoSize = true;
            this.lblServer.Location = new System.Drawing.Point(6, 29);
            this.lblServer.Name = "lblServer";
            this.lblServer.Size = new System.Drawing.Size(41, 12);
            this.lblServer.TabIndex = 16;
            this.lblServer.Text = "工具IP";
            // 
            // txtCameraName
            // 
            this.txtCameraName.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.txtCameraName.Location = new System.Drawing.Point(92, 20);
            this.txtCameraName.Name = "txtCameraName";
            this.txtCameraName.Size = new System.Drawing.Size(171, 21);
            this.txtCameraName.TabIndex = 17;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(17, 23);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 12);
            this.label18.TabIndex = 18;
            this.label18.Text = "设备型号:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblScreenStatus);
            this.groupBox2.Controls.Add(this.lblServer);
            this.groupBox2.Controls.Add(this.lblStatus);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(330, 88);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "网络状态:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnSaveAs);
            this.groupBox3.Controls.Add(this.btnSaveAll);
            this.groupBox3.Controls.Add(this.btnReadAll);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.btnWriteAll);
            this.groupBox3.Controls.Add(this.txtCameraName);
            this.groupBox3.Location = new System.Drawing.Point(358, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(383, 88);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "寄存器操作:";
            // 
            // btnSaveAs
            // 
            this.btnSaveAs.Location = new System.Drawing.Point(288, 50);
            this.btnSaveAs.Name = "btnSaveAs";
            this.btnSaveAs.Size = new System.Drawing.Size(87, 32);
            this.btnSaveAs.TabIndex = 19;
            this.btnSaveAs.Text = "另存为文件";
            this.btnSaveAs.UseVisualStyleBackColor = true;
            this.btnSaveAs.Click += new System.EventHandler(this.btnSaveAs_Click);
            // 
            // lblScreenStatus
            // 
            this.lblScreenStatus.AutoSize = true;
            this.lblScreenStatus.Location = new System.Drawing.Point(177, 29);
            this.lblScreenStatus.Name = "lblScreenStatus";
            this.lblScreenStatus.Size = new System.Drawing.Size(59, 12);
            this.lblScreenStatus.TabIndex = 17;
            this.lblScreenStatus.Text = "监控屏ID:";
            // 
            // RegConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1130, 533);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tablePanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "RegConfig";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "寄存器配置项";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RegConfig_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.RegConfig_FormClosed);
            this.Load += new System.EventHandler(this.RegConfig_Load);
            this.tablePanel.ResumeLayout(false);
            this.tablePanel.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reg11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reg0)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tablePanel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnRead0;
        private System.Windows.Forms.Button btnWrite0;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnWrite1;
        private System.Windows.Forms.TextBox addr11;
        private System.Windows.Forms.TextBox addr10;
        private System.Windows.Forms.TextBox addr9;
        private System.Windows.Forms.TextBox addr8;
        private System.Windows.Forms.TextBox addr7;
        private System.Windows.Forms.TextBox addr6;
        private System.Windows.Forms.TextBox addr5;
        private System.Windows.Forms.TextBox addr4;
        private System.Windows.Forms.TextBox addr3;
        private System.Windows.Forms.Button btnRead2;
        private System.Windows.Forms.TextBox addr2;
        private System.Windows.Forms.TextBox addr1;
        private System.Windows.Forms.TextBox val0;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnWrite2;
        private System.Windows.Forms.Button btnWrite3;
        private System.Windows.Forms.Button btnWrite4;
        private System.Windows.Forms.Button btnWrite5;
        private System.Windows.Forms.Button btnWrite6;
        private System.Windows.Forms.Button btnRead1;
        private System.Windows.Forms.TextBox addr0;
        private System.Windows.Forms.Button btnWrite7;
        private System.Windows.Forms.Button btnRead3;
        private System.Windows.Forms.Button btnRead4;
        private System.Windows.Forms.Button btnRead5;
        private System.Windows.Forms.Button btnRead6;
        private System.Windows.Forms.Button btnRead7;
        private System.Windows.Forms.Button btnWrite8;
        private System.Windows.Forms.Button btnRead8;
        private System.Windows.Forms.Button btnWrite9;
        private System.Windows.Forms.Button btnRead9;
        private System.Windows.Forms.Button btnWrite10;
        private System.Windows.Forms.Button btnRead10;
        private System.Windows.Forms.Button btnWrite11;
        private System.Windows.Forms.Button btnRead11;
        private System.Windows.Forms.Button btnReadAll;
        private System.Windows.Forms.Button btnWriteAll;
        private System.Windows.Forms.Button btnSaveAll;
        private System.Windows.Forms.NumericUpDown reg11;
        private System.Windows.Forms.NumericUpDown reg10;
        private System.Windows.Forms.NumericUpDown reg9;
        private System.Windows.Forms.NumericUpDown reg8;
        private System.Windows.Forms.NumericUpDown reg7;
        private System.Windows.Forms.NumericUpDown reg6;
        private System.Windows.Forms.NumericUpDown reg5;
        private System.Windows.Forms.NumericUpDown reg4;
        private System.Windows.Forms.NumericUpDown reg3;
        private System.Windows.Forms.NumericUpDown reg2;
        private System.Windows.Forms.NumericUpDown reg1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown reg0;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblServer;
        private System.Windows.Forms.TextBox txtCameraName;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button add11;
        private System.Windows.Forms.Button sub11;
        private System.Windows.Forms.TextBox val11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button add10;
        private System.Windows.Forms.Button sub10;
        private System.Windows.Forms.TextBox val10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button add9;
        private System.Windows.Forms.Button sub9;
        private System.Windows.Forms.TextBox val9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button add8;
        private System.Windows.Forms.Button sub8;
        private System.Windows.Forms.TextBox val8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button add7;
        private System.Windows.Forms.Button sub7;
        private System.Windows.Forms.TextBox val7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button add6;
        private System.Windows.Forms.Button sub6;
        private System.Windows.Forms.TextBox val6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button add5;
        private System.Windows.Forms.Button sub5;
        private System.Windows.Forms.TextBox val5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button add4;
        private System.Windows.Forms.Button sub4;
        private System.Windows.Forms.TextBox val4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button add3;
        private System.Windows.Forms.Button sub3;
        private System.Windows.Forms.TextBox val3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button add2;
        private System.Windows.Forms.Button sub2;
        private System.Windows.Forms.TextBox val2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button add1;
        private System.Windows.Forms.Button sub1;
        private System.Windows.Forms.TextBox val1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button add0;
        private System.Windows.Forms.Button sub0;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnSaveAs;
        private System.Windows.Forms.Label lblScreenStatus;
    }
}