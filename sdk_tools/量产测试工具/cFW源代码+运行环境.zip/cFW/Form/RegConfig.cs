﻿using cFW.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cFW
{
    public partial class RegConfig : Form
    {
        public string cfgHostname { get; set; }
        public int cfgPort { get; set; }
        public string serverHostname { get; set; }
        public int serverPort { get; set; }
        //监控屏ID号
        public int screenID { get; set; }

        public RegConfig()
        {
            InitializeComponent();
        }
        public void setTest(string msg)
        {
            Console.WriteLine(msg);
        }

        private void RegConfig_Load(object sender, EventArgs e)
        {
            /*
            cfgHostname = "192.168.96.1";
            cfgPort = 3335;
            serverHostname = "192.168.96.1";
            serverPort = 3334;
            screenID = 1;
            */
            if(cfgHostname == "" || cfgPort == 0)
            {
                MessageBox.Show("域名与端口为空", "提示");
                this.Close();
            }
            string msg = "设备IP[" + cfgHostname + ":" + cfgPort +"]";
            lblStatus.Text = msg;
            msg = "工具IP[" + serverHostname + ":" + serverPort + "]";
            lblServer.Text = msg;
            msg = "监控屏ID[" + screenID + "]";
            lblScreenStatus.Text = msg;
            readConfig();
            listenSSDP();
        }
        private void RegConfig_FormClosed(object sender, FormClosedEventArgs e)
        {
        }
        private void RegConfig_FormClosing(object sender, FormClosingEventArgs e)
        {
            writeConfig();
            unListenSSDP();
        }


        #region 读写操作事件
        private void btnWrite0_Click(object sender, EventArgs e)
        {
            string regid = reg0.Value.ToString();
            string addr = addr0.Text;
            string val = val0.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite1_Click(object sender, EventArgs e)
        {
            string regid = reg1.Value.ToString();
            string addr = addr1.Text;
            string val = val1.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite2_Click(object sender, EventArgs e)
        {
            string regid = reg2.Value.ToString();
            string addr = addr2.Text;
            string val = val2.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite3_Click(object sender, EventArgs e)
        {
            string regid = reg3.Value.ToString();
            string addr = addr3.Text;
            string val = val3.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite4_Click(object sender, EventArgs e)
        {
            string regid = reg4.Value.ToString();
            string addr = addr4.Text;
            string val = val4.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite5_Click(object sender, EventArgs e)
        {
            string regid = reg5.Value.ToString();
            string addr = addr5.Text;
            string val = val5.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite6_Click(object sender, EventArgs e)
        {
            string regid = reg6.Value.ToString();
            string addr = addr6.Text;
            string val = val6.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite7_Click(object sender, EventArgs e)
        {
            string regid = reg7.Value.ToString();
            string addr = addr7.Text;
            string val = val7.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite8_Click(object sender, EventArgs e)
        {
            string regid = reg8.Value.ToString();
            string addr = addr8.Text;
            string val = val8.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite9_Click(object sender, EventArgs e)
        {
            string regid = reg9.Value.ToString();
            string addr = addr9.Text;
            string val = val9.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite10_Click(object sender, EventArgs e)
        {
            string regid = reg10.Value.ToString();
            string addr = addr10.Text;
            string val = val10.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnWrite11_Click(object sender, EventArgs e)
        {
            string regid = reg11.Value.ToString();
            string addr = addr11.Text;
            string val = val11.Text;
            Dictionary<string, object> dic = getDic("write", regid, addr, val);
            sendToDevice(dic);
        }

        private void btnRead0_Click(object sender, EventArgs e)
        {
            string regid = reg0.Value.ToString();
            string addr = addr0.Text;
            string val = val0.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead1_Click(object sender, EventArgs e)
        {
            string regid = reg1.Value.ToString();
            string addr = addr1.Text;
            string val = val1.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead2_Click(object sender, EventArgs e)
        {
            string regid = reg2.Value.ToString();
            string addr = addr2.Text;
            string val = addr2.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead3_Click(object sender, EventArgs e)
        {
            string regid = reg3.Value.ToString();
            string addr = addr3.Text;
            string val = val3.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead4_Click(object sender, EventArgs e)
        {
            string regid = reg4.Value.ToString();
            string addr = addr4.Text;
            string val = val4.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead5_Click(object sender, EventArgs e)
        {
            string regid = reg5.Value.ToString();
            string addr = addr5.Text;
            string val = val5.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead6_Click(object sender, EventArgs e)
        {
            string regid = reg6.Value.ToString();
            string addr = addr6.Text;
            string val = val6.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead7_Click(object sender, EventArgs e)
        {
            string regid = reg7.Value.ToString();
            string addr = addr7.Text;
            string val = val7.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead8_Click(object sender, EventArgs e)
        {
            string regid = reg8.Value.ToString();
            string addr = addr8.Text;
            string val = val8.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead9_Click(object sender, EventArgs e)
        {
            string regid = reg9.Value.ToString();
            string addr = addr9.Text;
            string val = val9.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead10_Click(object sender, EventArgs e)
        {
            string regid = reg10.Value.ToString();
            string addr = addr10.Text;
            string val = val10.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private void btnRead11_Click(object sender, EventArgs e)
        {
            string regid = reg11.Value.ToString();
            string addr = addr11.Text;
            string val = val11.Text;
            Dictionary<string, object> dic = getDic("read", regid, addr, val);
            sendToDevice(dic);
        }
        private Dictionary<string, object> getDic(string type, string regid, string addr, string val)
        {
            if (string.IsNullOrEmpty(addr))
            {
                return null;
            }
            if (string.IsNullOrEmpty(val))
            {
                val = "0";
            }
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("CAMERA", "NULL");
            MSSDPRegModel reg = new MSSDPRegModel();
            reg.addr = addr;
            reg.value = val;
            dic.Add( type + "_reg" + regid, reg);
            return dic;
        }
        #endregion

        #region 加减操作事件

        private void sub0_Click(object sender, EventArgs e)
        {
            string val = val0.Text;
            val0.Text = subValueEvent(val);
        }
        private void sub1_Click(object sender, EventArgs e)
        {
            string val = val1.Text;
            val1.Text = subValueEvent(val);
        }
        private void sub2_Click(object sender, EventArgs e)
        {
            string val = val2.Text;
            val2.Text = subValueEvent(val);
        }
        private void sub3_Click(object sender, EventArgs e)
        {
            string val = val3.Text;
            val3.Text = subValueEvent(val);
        }
        private void sub4_Click(object sender, EventArgs e)
        {
            string val = val4.Text;
            val4.Text = subValueEvent(val);
        }
        private void sub5_Click(object sender, EventArgs e)
        {
            string val = val5.Text;
            val5.Text = subValueEvent(val);
        }
        private void sub6_Click(object sender, EventArgs e)
        {
            string val = val6.Text;
            val6.Text = subValueEvent(val);
        }
        private void sub7_Click(object sender, EventArgs e)
        {
            string val = val7.Text;
            val7.Text = subValueEvent(val);
        }
        private void sub8_Click(object sender, EventArgs e)
        {
            string val = val8.Text;
            val8.Text = subValueEvent(val);
        }
        private void sub9_Click(object sender, EventArgs e)
        {
            string val = val9.Text;
            val9.Text = subValueEvent(val);
        }
        private void sub10_Click(object sender, EventArgs e)
        {
            string val = val10.Text;
            val10.Text = subValueEvent(val);
        }
        private void sub11_Click(object sender, EventArgs e)
        {
            string val = val11.Text;
            val11.Text = subValueEvent(val);
        }

        private void add0_Click(object sender, EventArgs e)
        {
            string val = val0.Text;
            val0.Text = addValueEvent(val);
        }
        private void add1_Click(object sender, EventArgs e)
        {
            string val = val1.Text;
            val1.Text = addValueEvent(val);
        }
        private void add2_Click(object sender, EventArgs e)
        {
            string val = val2.Text;
            val2.Text = addValueEvent(val);
        }
        private void add3_Click(object sender, EventArgs e)
        {
            string val = val3.Text;
            val3.Text = addValueEvent(val);
        }
        private void add4_Click(object sender, EventArgs e)
        {
            string val = val4.Text;
            val4.Text = addValueEvent(val);
        }
        private void add5_Click(object sender, EventArgs e)
        {
            string val = val5.Text;
            val5.Text = addValueEvent(val);
        }
        private void add6_Click(object sender, EventArgs e)
        {
            string val = val6.Text;
            val6.Text = addValueEvent(val);
        }
        private void add7_Click(object sender, EventArgs e)
        {
            string val = val7.Text;
            val7.Text = addValueEvent(val);
        }
        private void add8_Click(object sender, EventArgs e)
        {
            string val = val8.Text;
            val8.Text = addValueEvent(val);
        }
        private void add9_Click(object sender, EventArgs e)
        {
            string val = val9.Text;
            val9.Text = addValueEvent(val);
        }
        private void add10_Click(object sender, EventArgs e)
        {
            string val = val10.Text;
            val10.Text = addValueEvent(val);
        }
        private void add11_Click(object sender, EventArgs e)
        {
            string val = val11.Text;
            val11.Text = addValueEvent(val);
        }
        private string subValueEvent(string val)
        {
            return valueEvent(val, "sub");
        }
        private string addValueEvent(string val)
        {
            return valueEvent(val, "add");
        }
        private string valueEvent(string val, string type)
        {
            string value = "0";
            if (string.IsNullOrEmpty(val))
            {
                return value;
            }
            val = val.Trim();
            val = val.ToLower();
            bool flag = false;
            if (val.StartsWith("0x"))
            {
                flag = true; //包含0x
                val = val.Replace("0x", "");
            }
            int v = Convert.ToInt32(val, 16);
            if (type == "add")
            {
                v = v + 1;
            }
            else if (type == "sub")
            {
                v = v - 1;
            }
            if (v < 0)
            {
                v = 0;
            }
            value = Convert.ToString(v, 16);
            if (value.Length == 1)
            {
                value = "0" + value;
            }
            if (flag == true)
            {
                value = "0x" + value;
            }
            return value;
        }
        #endregion

        #region 全读写，发送设备

        private void btnReadAll_Click(object sender, EventArgs e)
        {
            Dictionary<string, object> dic = getDicAll("read");
            sendToDevice(dic);
        }
        private void btnWriteAll_Click(object sender, EventArgs e)
        {
            Dictionary<string, object> dic = getDicAll("write");
            sendToDevice(dic);
        }
        private void btnSaveAll_Click(object sender, EventArgs e)
        {
            Dictionary<string, object> dic = getDicAll("save");
            sendToDevice(dic);
        }
        private Dictionary<string, object> getDicAll(string type)
        {
            List<RegConfigModel> list = getListRegConfig();
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("CAMERA", txtCameraName.Text);
            for (int i = 0; i < list.Count; i++)
            {
                string key = type + "_reg" + list[i].regid;
                MSSDPRegModel reg = new MSSDPRegModel();
                reg.addr = list[i].addr;
                reg.value = list[i].value;
                if (!dic.ContainsKey(key))
                {
                    dic.Add(key, reg);
                }
            }
            return dic;
        }

        private void sendToDevice(Dictionary<String, Object> dic)
        {
            if (dic == null)
            {
                LOG("数据为空");
                return;
            }
            string msg = JsonConvert.SerializeObject(dic);
            var data = Encoding.UTF8.GetBytes("MSSDP_REGISTER " + msg);
            LOG("发送数据: " + msg);
            //"255.255.255.255"
            udpClient.Send(data, data.Length, cfgHostname, cfgPort);
        }
        //另存为
        private void btnSaveAs_Click(object sender, EventArgs e)
        {
            List<RegConfigModel> list = getListRegConfig();
            string data = "";
            for(int i=0; i<list.Count; i++)
            {
                RegConfigModel cell = list[i];
                data += "{" + cell.addr + "," + cell.value + "},\r\n";
            }
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "txt files (*.*)|*.*";
            dialog.FilterIndex = 2;
            dialog.RestoreDirectory = true;
            if(dialog.ShowDialog() == DialogResult.OK)
            {
                Stream os;
                if((os = dialog.OpenFile()) != null)
                {
                    using (StreamWriter sw = new StreamWriter(os))
                    {
                        sw.Write(data);
                    }
                    os.Close();
                    MessageBox.Show("保存成功", "另存为寄存器配置");
                }
            }
        }
        #endregion

        #region 限制输入

        private void val0_KeyUp(object sender, KeyEventArgs e)
        {
            val0.Text = valHexInput(val0.Text);
        }
        private void val1_KeyUp(object sender, KeyEventArgs e)
        {
            val1.Text = valHexInput(val1.Text);
        }
        private void val2_KeyUp(object sender, KeyEventArgs e)
        {
            val2.Text = valHexInput(val2.Text);
        }
        private void val3_KeyUp(object sender, KeyEventArgs e)
        {
            val3.Text = valHexInput(val3.Text);
        }
        private void val4_KeyUp(object sender, KeyEventArgs e)
        {
            val4.Text = valHexInput(val4.Text);
        }
        private void val5_KeyUp(object sender, KeyEventArgs e)
        {
            val5.Text = valHexInput(val5.Text);
        }
        private void val6_KeyUp(object sender, KeyEventArgs e)
        {
            val6.Text = valHexInput(val6.Text);
        }
        private void val7_KeyUp(object sender, KeyEventArgs e)
        {
            val7.Text = valHexInput(val7.Text);
        }
        private void val8_KeyUp(object sender, KeyEventArgs e)
        {
            val8.Text = valHexInput(val8.Text);
        }
        private void val9_KeyUp(object sender, KeyEventArgs e)
        {
            val9.Text = valHexInput(val9.Text);
        }
        private void val10_KeyUp(object sender, KeyEventArgs e)
        {
            val10.Text = valHexInput(val10.Text);
        }
        private void val11_KeyUp(object sender, KeyEventArgs e)
        {
            val11.Text = valHexInput(val11.Text);
        }
        private string valHexInput(string val)
        {
            string str = "";
            for (int i = 0; i < val.Length; i++)
            {
                char ch = val[i];
                if (ch >= '0' && ch <= '9')
                    str += ch;
                if (ch >= 'a' && ch <= 'f')
                    str += ch;
                if (ch >= 'A' && ch <= 'F')
                    str += ch;
                if (ch == 'x' || ch == 'X')
                    str += ch;
            }
            return str;
        }
        #endregion

        #region Socket功能
        private UdpClient udpClient = null;
        private void listenSSDP()
        {
            udpClient = new UdpClient();
            int PORT = this.serverPort;
            string ip = this.serverHostname;
            LOG("监听IP " + ip + ":" + PORT);
            udpClient.Client.Bind(new IPEndPoint(IPAddress.Parse(ip), PORT));//

            var from = new IPEndPoint(0, 0);
            Task.Run(() =>
            {
                try
                {
                    while (true)
                    {
                        try
                        {
                            var recvBuffer = udpClient.Receive(ref from);
                            string str = Encoding.UTF8.GetString(recvBuffer);
                            string[] vals = str.Split(' ');
                            if (vals.Length < 2)
                            {
                                continue;
                            }
                            string type = str.Split(' ')[0];
                            string json = str.Replace(type, "");
                            string hostname = from.Address + ":" + from.Port;
                            if (type == "MSSDP_REGISTER")
                            {
                                json = json.Trim();
                                LOG("收到广播: " + hostname + "[" + "]=> " + json);
                                mssdpRegisterEvent(json);
                            }
                            else
                            {
                                LOG("收到广播: " + hostname + "[.]=> " + type);
                            }
                        }
                        catch (ObjectDisposedException ex)
                        {
                            LOG("异常ObjectDisposedException:" + ex.Message);
                            break;
                        }
                        catch (SocketException ex)
                        {
                            LOG("异常SocketException:" + ex.Message);
                            break;
                        }
                        catch (Exception ex)
                        {
                            LOG("异常:" + ex.Message);
                            //break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    LOG("关闭:" + ex.Message);
                }
            });
        }
        private void unListenSSDP()
        {
            udpClient.Close();
        }

        private bool mssdpRegisterEvent(string json)
        {
            Dictionary<string, object> register = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
            if (register.ContainsKey("CAMERA"))
            {
                Invoke(new MethodInvoker(delegate ()
                {
                    txtCameraName.Text = register["CAMERA"].ToString();
                }));
            }
            foreach (var dic in register)
            {
                string key = dic.Key;
                if (!key.StartsWith("read_reg"))
                {
                    continue;
                }
                int regid = Convert.ToInt32(key.Replace("read_reg", ""));
                string value = dic.Value.ToString();
                Console.WriteLine(regid + " " + value);
                RegConfigModel cell = JsonConvert.DeserializeObject<RegConfigModel>(value);
                Invoke(new MethodInvoker(delegate ()
                {
                    for(int i=0; i<12; i++)
                    {
                        string regName = "reg" + i;
                        NumericUpDown c = (NumericUpDown)findTablePanel(regName);
                        if (c == null)
                        {
                            return;
                        }
                        if (c.Value == regid)
                        {
                            string addrName = "addr" + i;
                            string valName = "val" + i;
                            TextBox b = (TextBox)findTablePanel(addrName);
                            b.Text = cell.addr;
                            b = (TextBox)findTablePanel(valName);
                            b.Text = cell.value;
                        }
                    }
                }));
            }
            return true;
        }
        private Control findTablePanel(string name)
        {
            foreach (Control ctrl in this.tablePanel.Controls)
            {
                if(ctrl.Name == name)
                {
                    return ctrl;
                }
            }
            if (name == "val0") { return val0; }
            if (name == "val1") { return val1; }
            if (name == "val2") { return val2; }
            if (name == "val3") { return val3; }
            if (name == "val4") { return val4; }
            if (name == "val5") { return val5; }
            if (name == "val6") { return val6; }
            if (name == "val7") { return val7; }
            if (name == "val8") { return val8; }
            if (name == "val9") { return val9; }
            if (name == "val10") { return val10; }
            if (name == "val11") { return val11; }
            return null;
        }
        #endregion

        #region 日志功能
        /// <summary>
        /// 日志
        /// </summary>
        /// <param name="msg"></param>
        public void LOG(string msg)
        {
            try
            {
                Invoke(new MethodInvoker(delegate ()
                {
                    var str = txtLog.Text;
                    if (str.Length > 128 * 1024)
                    {
                        str = str.Substring(0, 32 * 1024);
                        Console.WriteLine("substring..");
                    }
                    DateTime dt = DateTime.Now;
                    var ss = "[" + string.Format("{0:HH:mm:ss.fff}", dt) + "] " + msg + "\r\n" + str;
                    txtLog.Text = ss;
                }));
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtLog.Text = "";
        }

        #endregion

        private List<RegConfigModel> getListRegConfig()
        {
            List<RegConfigModel> list = new List<RegConfigModel>();
            for (int i = 0; i < 12; i++)
            {
                string regName = "reg" + i;
                string addrName = "addr" + i;
                string valName = "val" + i;
                NumericUpDown num = (NumericUpDown)findTablePanel(regName);
                int regVal = decimal.ToInt32(num.Value);
                TextBox addr = (TextBox)findTablePanel(addrName);
                string addrVal = addr.Text;
                TextBox val = (TextBox)findTablePanel(valName);
                string valVal = val.Text;
                if (string.IsNullOrEmpty(addrVal))
                {
                    continue;
                }
                RegConfigModel cell = new RegConfigModel();
                Console.WriteLine(cell);
                cell.regid = regVal;
                cell.addr = addrVal;
                cell.value = valVal;
                list.Add(cell);
            }
            return list;
        }

        #region 配置保存与读取
        private bool readConfig()
        {
            try
            {
                byte[] bytes = new byte[2048];
                FileStream file = new FileStream(@"./config/screen" + screenID + ".ini", FileMode.Open);
                file.Seek(0, SeekOrigin.Begin);
                int cnt = file.Read(bytes, 0, bytes.Length);
                file.Close();
                string json = Encoding.UTF8.GetString(bytes, 0, cnt);
                if(json == null)
                {
                    return false;
                }
                List<RegConfigModel> list = JsonConvert.DeserializeObject<List<RegConfigModel>>(json);
                for(int i=0; i<list.Count; i++)
                {
                    RegConfigModel cell = list[i];
                    //string regName = "reg" + i;
                    string addrName = "addr" + i;
                    string valName = "val" + i;
                    int regVal = list[i].regid;
                    string addrVal = list[i].addr;
                    string valVal = list[i].value;

                    //NumericUpDown num = (NumericUpDown)findTablePanel(regName);
                    //num.Value = regVal;
                    TextBox addr = (TextBox)findTablePanel(addrName);
                    addr.Text = addrVal;
                    TextBox val = (TextBox)findTablePanel(valName);
                    val.Text = valVal;
                }
            }catch(Exception ex)
            {
                LOG("没有找到配置文件." + ex.Message);
            }
            return true;
        }
        private bool writeConfig()
        {
            if (!Directory.Exists(@"./config"))
            {
                Directory.CreateDirectory(@"./config");
            }
            List<RegConfigModel> list = getListRegConfig();
            string json = JsonConvert.SerializeObject(list);
            Console.WriteLine(json);
            File.WriteAllText(@"./config/screen"+ screenID + ".ini", json);
            return true;
        }
        #endregion

    }
}
