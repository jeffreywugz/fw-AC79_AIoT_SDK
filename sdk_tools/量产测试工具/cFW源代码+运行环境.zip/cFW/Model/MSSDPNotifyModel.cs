﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPCTool
{
    class MSSDPNotifyModel
    {
        public string RTSP { get; set; }
        public string SIGNAL { get; set; }
        public string SD_STATUS { get; set; }
        public string DEV_ONLINE_FLAG { get; set; }
        public string KEY0 { get; set; }
        public string KEY1 { get; set; }
        public string dB { get; set; }
        public string BAT_VOL { get; set; }
        public string UID { get; set; }
        public string RX_DATA { get; set; }
        public long tick { get; set; }
        public string hostname { get; set; }
        public int port { get; set; }
    }
}
