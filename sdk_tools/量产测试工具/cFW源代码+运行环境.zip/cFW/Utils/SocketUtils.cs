﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPCTool
{
    class SocketUtils
    {
        public static List<string> GetLocalIP()
        {
            List<string> list = new List<string>();
            try
            {
                IPAddress[] ipArray;
                ipArray = Dns.GetHostAddresses(Dns.GetHostName());
                for(int i=0; i< ipArray.Length; i++)
                {
                    if(ipArray[i].IsIPv6LinkLocal == false)
                    {
                        list.Add(ipArray[i].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace + "\r\n" + ex.Message, "错误", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
            list.Sort((x, y) => -x.CompareTo(y));
            list.Add("0.0.0.0");
            //list.Add("127.0.0.1");
            return list;
        }
    }
}
