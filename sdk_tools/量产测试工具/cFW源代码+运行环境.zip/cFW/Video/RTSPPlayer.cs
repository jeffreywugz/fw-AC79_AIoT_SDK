﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPCTool
{
    class RTSPPlayer
    {
        FFmpegUtils rtmp = new FFmpegUtils();
        Thread player;
        string url;
        PictureBox video;
        Form that;
        bool status = false;

        public RTSPPlayer(Form from, PictureBox video)
        {
            this.video = video;
            this.that = from;
        }
        public void play(string url)
        {
            this.url = url;
            if (player != null)
            {
                rtmp.Stop();
                player = null;
            }
            player = new Thread(DeCoding);
            player.IsBackground = true;
            player.Start();
            status = true;
        }
        public void stop()
        {
            if(player != null)
            {
                rtmp.Stop();
                player = null;
                video.Image = cFW.Properties.Resources.loading;
            }
            video.Image = cFW.Properties.Resources.loading;
            status = false;
        }
        public bool isRunning()
        {
            return status;
        }

        private unsafe void DeCoding()
        {
            try
            {
                Console.WriteLine("Decoding run ...");
                Bitmap oldBmp = null;
                FFmpegUtils.ShowBitmap show = (bmp) =>
                {
                    that.Invoke(new MethodInvoker(() =>
                    {
                        video.Image = bmp;
                        if (oldBmp != null)
                        {
                            oldBmp.Dispose();
                        }
                        oldBmp = bmp;
                    }));
                };
                rtmp.Start(show, url.Trim());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            finally
            {
                Console.WriteLine("DeCoding exit");
                stop();
            }
        }
    }
}
